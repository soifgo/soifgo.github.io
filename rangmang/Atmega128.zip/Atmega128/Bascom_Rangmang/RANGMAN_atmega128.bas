' ==============================================================================
' Developer: Saeid Moghadam
' Email: SSMQQMSS@gmail.com
' Project: SoifGo (Rangmang Controller)
' Hardware: ATmega128 (Supports up to 999 pixels)
' Protocol Specification (30 Inputs / Dynamic Command Length)
' ==============================================================================
' --- Data Packet Format ---
' Pattern: A(adr) D(mode) R(red) G(green) B(blue) S(start/delay1) E(end/delay2) M(memory/pixels)
' Example: A1D0R255G0B0S0E180M0
' --- [A] ADDRESS MODULE ---
' A1 to A98 : Specific Module Address
' A99        : Broadcast to All Modules
' --- [D0] SOLID COLOR MODE (Static Display) ---
' D0        : Activates Solid Color Mode
' R0   - R255 : Red Intensity
' G0   - G255 : Green Intensity
' B0   - B255 : Blue Intensity
' S0   - S999 : RGB Strip START Position for Colored Pixels
' E0   - E999 : RGB Strip END Position for Colored Pixels
' M0          : Preview Mode (Run without saving to EEPROM)
' M1          : Save current settings to Slot 1 Memory
' --- [D1 to D55] DANCE / EFFECT MODE ---
' D1  - D55  : Select Specific Dance/Light Effect
' D99        : Auto-Random Selection (Cycles through D01 to D55)
' R0   - R250 : Fixed Red   | R251 to R255 : Random Red Intensity
' G0   - G250 : Fixed Green | G251 to G255 : Random Green Intensity
' B0   - B250 : Fixed Blue  | B251 to B255 : Random Blue Intensity
' S0   - S999 : First Effect Delay (ms)
' E0   - E999 : Second Effect Delay (ms)
' M1   - M999 : Set Total Number of Active Dancing Pixels
' ==============================================================================


$regfile = "m128def.dat"
$crystal = 1105920
$prog &HFF , &HBE , &HCF , &HFE       ' generated. Take care that the chip supports all fuse bytes.
$hwstack = 40
$swstack = 16
$framesize = 32
 '----[ADC / SOUND]--------------------------------------------------------------
Config Adc = Single , Prescaler = Auto , Reference = Avcc
Start Adc

Dim Ina As Bit      'external crystal 11059200
Config Watchdog = 1024
 Enable Interrupts
 $baud = 960
 Reset Watchdog
Ff:
'----[MAIN]---------------------------------------------------------------------
   Dim Danc , Dan , Dans As Byte
   Dim N , Nd , Ns , Nf , Jj , Led , S , Ii , I , T As Word
   Dim Ch , Ch0 , A1 , A2 , A3 As Byte
   Dim Text As String * 36
   Dim Trig , Trigf As String * 5
   Dim Trig2 As String * 5
   Dim Rq(99) , Gq(99) , Bq(99) As Byte
   Dim Rgb , Mmr , Mmg , Mmb As Byte
   Dim Tim1 , Tim2 , Tt1 , Tt2 , Ado , Ll , Adss , Adss2 , Adsm , Adsm2 As Word
   Dim Rr , Gg , Bb As Byte
   Dim Rx , Gx , Bx As Byte
   Dim Chc , Nnb , Mx , Rainbo As Bit
   Dim Jk , Kk , Lk As Word
   Dim Dvado As Word
Dim Wp As Word
Dim Wk As Word
Dim Wv As Word
Dim Wlen As Word
Dim Mq As Word
Dim Mh As Word
Dim Mw As Word
Dim Tc As Word
Dim Tq As Word
Dim Fq As Word
Dim Fh As Word
Dim Fm As Word
Dim Fp As Word
Dim Fv As Word
Dim Fc As Byte
Dim Fmode As Byte
Dim Flim As Word
Dim Fmid As Word
Dim Fa As Word
Dim Fb As Word
Dim Dc As Byte
Dim Dn As Byte
Dim Dw As Word
Dim Dpos As Word
Dim Dmax As Word
Dim Da As Word
Dim Db As Word
Dim Dv As Word
Dim Kc As Word
Dim Kn As Byte
Dim Kq As Word
Dim Kr As Byte
Dim Kg As Byte
Dim Kb As Byte
Dim Zb As Word
Dim Zn As Word
Dim Zp As Word
Dim Zs As Word
Dim Zl As Word
Dim Zt As Word
Dim Ze As Word
Dim Zk As Word
Dim Zy As Word
Dim Zx As Word
Dim Za As Word
Dim Zc As Word
Dim Zv As Word
Dim Zmid As Word
Dim Zlast As Word
Dim Zmode As Byte
Dim Hc As Byte
Dim Hn As Byte
Dim Hl As Word
Dim Hp As Word
Dim Hmax As Word
Dim Lc As Byte
Dim Lf As Byte
Dim Lp As Word
Dim Lw As Word
Dim Lmax As Word
Dim La As Word
Dim Lb As Word
Dim Pc As Word
Dim Pa As Word
Dim Pb As Word
Dim Pk As Word
Dim Pv As Word
Dim Pw As Word
Dim Pq As Word
Dim Qc As Byte
Dim Qp As Word
Dim Qk As Word
Dim Qa As Word
Dim Qb As Word
Dim Qv As Word
Dim Qlen As Word
Dim Qr As Byte
Dim Qg As Byte
Dim Qbl As Byte
Dim Qh As Word
Dim Qhr As Byte
Dim Qhg As Byte
Dim Qhb As Byte
Dim Tsc As Byte
Dim Tsw As Word
Dim Tsp As Word
Dim Tsq As Word
Dim Tsk As Word
Dim Tsh As Word
Dim Tsr As Byte
Dim Tsg As Byte
Dim Tsb As Byte
Dim Mtp(4) As Word
Dim Mtl(4) As Byte
Dim Mti As Byte
Dim Mtf As Word
Dim Mtk As Word
Dim Mta As Word
Dim Mtv As Word
Dim Mtc As Word
Dim Mtd As Byte
Dim Pdc As Byte
Dim Pdt As Word
Dim Pdk As Word
Dim Pdx As Word
Dim Pda As Word
Dim Pdb As Word
Dim Pdv As Word
Dim Pdw As Word
Dim Pdr As Byte
Dim Pdg As Byte
Dim Pdbl As Byte
Dim Gsc As Byte
Dim Gsp As Word
Dim Gsk As Word
Dim Gsh As Word
Dim Gsv As Word
Dim Gsw As Word
Dim Gsr As Byte
Dim Gsg As Byte
Dim Gsb As Byte
Dim Prc As Byte
Dim Prp As Word
Dim Prd As Word
Dim Prk As Word
Dim Prh As Word
Dim Prw As Word
Dim Prv As Word
Dim Prm As Word
Dim Prz As Byte
Dim Prr As Byte
Dim Prg As Byte
Dim Prbl As Byte
Dim Evc As Word
Dim Evl As Word
Dim Evt As Word
Dim Evk As Word
Dim Evs As Word
Dim Evw As Word
Dim Eva As Word
Dim Evh As Byte
Dim Evr As Byte
Dim Evg As Byte
Dim Evb As Byte
Dim Evm As Byte
Dim Evv As Word
Dim Evx As Word
Dim Evy As Word
Dim Evz As Word
Dim Evd As Word
Dim Cfc As Byte
Dim Cfs As Byte
Dim Cfw As Word
Dim Cfa(3) As Byte
Dim Cfb(3) As Byte
Dim Cfg(3) As Byte
Dim Cfi As Byte
Dim Cfj As Byte
Dim Wcc As Byte
Dim Wcp As Word
Dim Wck As Word
Dim Wcw As Word
Dim Wch As Word
Dim Wca As Word
Dim Wcb As Word
Dim Wcv As Word
Dim Wcr As Byte
Dim Wcg As Byte
Dim Wcb2 As Byte
Dim Bmcnt As Byte
Dim Bmrad As Word
Dim Bmdist As Word
Dim Bmmid As Word
Dim Bmstep As Word
Dim Bmwgt As Word
Dim Bmbri As Word
Dim Bmfade As Word
Dim Bmrot1 As Byte
Dim Bmrot2 As Byte
Dim Bmrot3 As Byte
Dim Wglfrm As Word
Dim Wglctr As Word
Dim Wgldir As Byte
Dim Wglcnt As Word
Dim Wglhlf As Word
Dim Wglstp As Word
Dim Wglbeg As Word
Dim Wglend As Word
Dim Wgldst As Word
Dim Wglwgt As Word
Dim Wglidx As Word
Dim Wglbrt As Word
Dim Wglphs As Word
''''''''''''''''''''''''''''''sound

Dim Adcval As Word
Dim Adcmin As Word
Dim Adcmax As Word
Dim Adcamp As Word
Dim Adcidx As Byte
Dim Noise As Byte
Dim Head As Byte

Dim Level As Word
Dim Target As Word
Dim Tmp As Long
Dim Oldlevel As Word

''''''''''''''''''''''''''''''''''
  Dim Xfd , Yfd , Vfd , Bfd As Word


   Dim Memoclr As Byte
   Declare Sub Memclr       ' select first chann
   Declare Sub Chekm
   Declare Sub Time1
   Declare Sub Time2
   Readeeprom Ch0 , 1
   Readeeprom Dan , 2
   Readeeprom Rr , 3
   Readeeprom Gg , 4
   Readeeprom Bb , 5
   Readeeprom Led , 6
   Readeeprom Memoclr , 9
   Readeeprom Tim1 , 10
   Readeeprom Tim2 , 12
   Call Chekm
   If Ch0 > 98 Or Ch0 < 1 Then Ch0 = 1
   If Dan > 99 Then Dan = 0
   If Led > 990 Then Led = 990

    If Memoclr = 0 Or Memoclr > 1 Then
      Call Memclr
      Memoclr = 1
      Writeeeprom Memoclr , 9
    End If

     Declare Sub Modh
       Declare Sub Snak_run_slow
  Declare Sub Snak_return_slow
  Declare Sub Snak_run_fast
  Declare Sub Snak_return_fast
  Declare Sub Snak_run_slow_random
  Declare Sub Snak_return_slow_random
  Declare Sub Snak_run_fast_random
  Declare Sub Snak_return_fast_random
  Declare Sub Snak_runreturn_slow_random
  Declare Sub Half_snak_out_mid_slow
  Declare Sub Half_half_right_slow
  Declare Sub Half_half_left_slow
  Declare Sub Star_runreturn_slow
  Declare Sub Star_run_slow
  Declare Sub Star_run_fast
  Declare Sub Star_return_fast
  Declare Sub Snak_growup_slow
  Declare Sub Star_playful
  Declare Sub Snak_star_playful
  Declare Sub Star_fillers
  Declare Sub Movable_light
  Declare Sub Snak_runreturn_colored
  Declare Sub Star_diamonds_blink_slow
  Declare Sub Star_diamonds_blink_fast
  Declare Sub Star_diamonds_blink_faster
  Declare Sub Disco
  Declare Sub Fillstripe_color
  Declare Sub Breathing
  Declare Sub Percolate_run
  Declare Sub Percolate_return
  Declare Sub Snak_1_2_run
  Declare Sub Snak_1_2_return
  Declare Sub Snak_1_2_run_rev
  Declare Sub Snak_1_2_return_rev
  Declare Sub Snak_relax_run
  Declare Sub Snak_relax_return
  Declare Sub Snak_rainbow
  Declare Sub Snak_rainbow_lp
  Declare Sub Snak_rainbow_bl
  Declare Sub Snak_rise_fall_blink
  Declare Sub Comet_bounce
  Declare Sub Twinkle_fade
  Declare Sub Wave_pulse
  Declare Sub Wave_pulse_rev
  Declare Sub Wave_pulse_rr
  Declare Sub Meteor_rain
  Declare Sub Theater_chase
  Declare Sub Fire_core
  Declare Sub Fire_flame
  Declare Sub Fire_flame_rev
  Declare Sub Fire_edges_in
  Declare Sub Fire_center_out
  Declare Sub Rain_drops
  Declare Sub Sparkle_two
  Declare Sub Stack_put
  Declare Sub Stack_core
  Declare Sub Stack_fill
  Declare Sub Stack_fill_rev
  Declare Sub Stack_edges_in
  Declare Sub Stack_center_out
  Declare Sub Heart_beat
  Declare Sub Heart_pulse
  Declare Sub Lightning
  Declare Sub Plasma_wave
  Declare Sub Snake_cross
  Declare Sub Stripes_slide
  Declare Sub Meteor_core
  Declare Sub Meteor_shower
  Declare Sub Meteor_shower_rev
  Declare Sub Pendulum
  Declare Sub Gradient_scroll
  Declare Sub Pulse_rings
  Declare Sub Pulse_rings_draw
  Declare Sub Pulse_rings_draw_in
Declare Sub Eq_put
Declare Sub Eq_core
Declare Sub Equalizer_bar
Declare Sub Equalizer_bar_rev
Declare Sub Equalizer_edges_in
Declare Sub Equalizer_center_out
Declare Sub Color_fade_walk
Declare Sub Wave_collision
Declare Sub Center_bloom
Declare Sub Wander_block
Declare Sub Sound_echo
Declare Sub Sound_breathing
Declare Sub Sound_center_out
Declare Sub Sound_edges_in
Declare Sub Sound_bar_peak
Declare Sub Sound_sparkle
   Danc = Dan

   Config Rainbow = 1 , Rb0_len = 999 , Rb0_port = Portf , Rb0_pin = 3
   Dim Color(3) As Byte
   R Alias Color(_base) : G Alias Color(_base + 1) : B Alias Color(_base + 2)
   Rb_selectchannel 0
   Rb_clearcolors
   Rb_clearstripe

   Reset Watchdog
  If Dan = 0 Then
   For I = 1 To 98
      Mmr = I + 100
      Mmg = I + 200
      Mmb = I + 300

      Readeeprom Rgb , Mmr
      Rq(i) = Rgb
      Readeeprom Rgb , Mmg
      Gq(i) = Rgb
      Readeeprom Rgb , Mmb
      Bq(i) = Rgb
      Reset Watchdog

      If Led > 0 And Led < 99 Then
            Reset Watchdog
            Adss = I * 4
            Adss = Adss + 396
            R = Rq(i) : G = Gq(i) : B = Bq(i)
           Adss2 = Adss + 2
            Readeeprom Adsm , Adss
             Readeeprom Adsm2 , Adss2
            For S = Adsm To Adsm2
               Reset Watchdog
               Rb_setcolor S , Color(1)
            Next

               Rb_send
      Else
         If Led = 999 Then
            Reset Watchdog
            R = Rr : G = Gg : B = Bb
            Rb_fillstripe Color
         End If
      End If

   Next

  Else
   Call Modh
  End If

 Config Serialin = Buffered , Size = 38 , Bytematch = 13
   Reset Watchdog
   Clear Serialin
   '''''''''''''''''''''''''''''dance subs'''''''''


   Echo On
   Echo Off
Do
  Main:
   Reset Watchdog
   If Ina = 1 Then Goto Red
  If Danc > 0 And Ina = 0 Then Call Modh
Loop

  Serial0charmatch:
  Input Text
  Ina = 1
Return


Red:

 Ina = 0
  Text = Trim(text)
  Text = Ltrim(text)


  Reset Watchdog
  ''''''''''''''''''''''''''''''''''''''''''''ch

If Instr(text , "CH") > 0 Then

      Dim Pos_equal As Byte
      Pos_equal = Instr(text , "=")

      If Pos_equal > 3 Then

         Dim Len_old As Byte
         Len_old = Pos_equal - 3
         Trig = Mid(text , 3 , Len_old)


         If Ch0 = Val(trig) Then

            Dim Start_new As Byte
            Start_new = Pos_equal + 1
            Trig2 = Mid(text , Start_new)

            Ch = Val(trig2)
            If Ch > 0 And Ch < 99 Then
               Ch0 = Ch
               Writeeeprom Ch0 , 1
               Print "New Address=" ; Ch0
            End If
         End If
      End If
   End If
   '''''''''''''''''''''''''''''''''''''''''
   '''''''''''''''''''''''''''''''''''''''''
   Hh:
   '''''''''''''''''''''''''''''
     Dim S0 , N0 As Byte
    For N0 = 1 To 32
     Reset Watchdog
         S0 = N0 + 1
       Trig = Mid(text , N0 , 1 )
     '''''''''''''''''''''''''''''''''''''''''''A
     If Instr(trig , "A") > 0 Then
         Trigf = Mid(text , S0 , 2)
       If Trigf <> "" Then
          If Val(trigf) > 0 And Val(trigf) < 100 Then Ch = Val(trigf)
       End If
     End If
     '''''''''''''''''''''''''''''''''

         If Ch = Ch0 Or Ch = 99 Then
             ''''''''''''''''''''''''''''''''''''Dance
           If Instr(trig , "D") > 0 Then
              Trigf = Mid(text , S0 , 2)
             If Val(trigf) >= 0 And Val(trigf) < 100 Then
              Danc = Val(trigf)
              Dan = Danc

             End If
           End If
           '''''''''''''''''''''''''''''''''''
                    '''''''''''''''''''''''''''RGBM
                       If Instr(trig , "R") > 0 Then
                          Trigf = Mid(text , S0 , 3)
                          If Val(trigf) >= 0 And Val(trigf) < 256 Then
                           R = Val(trigf)
                           Rr = R
                          End If
                       End If
                       If Instr(trig , "G") > 0 Then
                          Trigf = Mid(text , S0 , 3)
                           If Val(trigf) >= 0 And Val(trigf) < 256 Then
                            G = Val(trigf)
                            Gg = G
                           End If
                       End If
                       If Instr(trig , "B") > 0 Then
                          Trigf = Mid(text , S0 , 3)
                           If Val(trigf) >= 0 And Val(trigf) < 256 Then
                            B = Val(trigf)
                            Bb = B
                           End If
                       End If
                       If Instr(trig , "M") > 0 Then
                          Trigf = Mid(text , S0 , 3)
                          If Val(trigf) >= 0 And Val(trigf) < 1000 Then Led = Val(trigf)
                       End If
                       '''''''''''''''''''''''''''''''
              Reset Watchdog


            If Dan = 0 Then
            ''''''''''''''''''''''''''pixel Start  End
                       If Instr(trig , "S") > 0 Then
                          Trigf = Mid(text , S0 , 3)
                          If Val(trigf) >= 0 And Val(trigf) < 1000 Then Ns = Val(trigf)
                       End If
                       If Instr(trig , "E") > 0 Then
                          Trigf = Mid(text , S0 , 3)
                          If Val(trigf) >= 0 And Val(trigf) < 1000 Then Nf = Val(trigf)
                       End If
                '''''''''''''''''''''''''''''''''''''''''''''''''
            Else

               ''''''''''''''''''''''''''Time Start  End
                       If Instr(trig , "S") > 0 Then
                          Trigf = Mid(text , S0 , 3)
                          If Val(trigf) >= 0 And Val(trigf) < 1000 Then Tim1 = Val(trigf)
                       End If
                       If Instr(trig , "E") > 0 Then
                          Trigf = Mid(text , S0 , 3)
                          If Val(trigf) >= 0 And Val(trigf) < 1000 Then Tim2 = Val(trigf)
                       End If
                       ''''''''''''''''''''''''''''''''''''''''''''''''''''
            End If

         End If
    Next


                If Dan >= 0 And Dan < 100 Then Writeeeprom Dan , 2


            If Dan = 0 Then

               If Led > 0 And Led < 99 Then
                  Writeeeprom Led , 6
                  Adss = Led * 4
                  Adss = Adss - 2
                   Adss = 790 - Adss
                  Writeeeprom Ns , Adss
                    Adss = Adss + 2
                  Writeeeprom Nf , Adss
                  Mmr = 199 - Led
                  Mmg = 299 - Led
                  Mmb = 399 - Led
                  Writeeeprom Rr , Mmr
                  Writeeeprom Gg , Mmg
                  Writeeeprom Bb , Mmb
                   Reset Watchdog
                  R = Rr : G = Gg : B = Bb
                  For I = Ns To Nf
                     Reset Watchdog
                     Rb_setcolor I , Color(1)
                  Next
                     Rb_send
                     Waitms 1
               Else
               Select Case Led
                  Case 0:
                     R = Rr : G = Gg : B = Bb
                     For I = Ns To Nf
                        Reset Watchdog
                        Rb_setcolor I , Color(1)
                     Next
                       Rb_send
                        Waitms 1
                  Case 996:
                      Call Memclr
                  Case 997:
                     Rb_clearstripe
                     Waitms 100
                  Case 998:
                     R = Rr : G = Gg : B = Bb
                     Rb_fillstripe Color
                     Waitms 100
                  Case 999:
                     R = Rr : G = Gg : B = Bb
                     Rb_fillstripe Color
                     Waitms 1
                     Writeeeprom Rr , 3
                     Writeeeprom Gg , 4
                     Writeeeprom Bb , 5
                     Led = 999
                     Writeeeprom Led , 6
               End Select
               End If
               Reset Watchdog
            Else
              If Led < 1 Then Led = 1
              If Led > 999 Then Led = 999

               Call Chekm
               If Danc > 0 And Danc < 100 Then
                  Writeeeprom Rr , 3
                  Writeeeprom Gg , 4
                  Writeeeprom Bb , 5
                  Writeeeprom Led , 6
                  Writeeeprom Tim1 , 10
                  Writeeeprom Tim2 , 12
                  Reset Watchdog
               End If
            End If

'   '''''''''''''''''''''''''''''''''''




        'Print "a=" ; Ch ; "d=" ; Danc ; "r=" ; Rr ; "g=" ; Gg ; "b=" ; _
        ' Bb ; "s=" ; Ns ; "e=" ; Nf ; "m=" ; Led
      Text = ""
      Trig = ""
       Trigf = ""
        Trig2 = ""
      Ch = ""
      Reset Watchdog
      Clear Serialin
Goto Main

Sub Modh

   If Led = 0 Then Led = 1
   If Danc = 99 Then
        Reset Watchdog
         Dans = Rnd(98)
   Else
      Dans = Danc - 1

   End If

  If Rr < 251 Then
      Rx = Rr
   Else
      Rx = 251
      Select Case Rr
         Case 251
            Rx = Rnd(15)
         Case 252
            Rx = Rnd(30)
         Case 253
            Rx = Rnd(60)
         Case 254
            Rx = Rnd(120)
         Case 255
            Rx = Rnd(250)
      End Select
      R = Rx
   End If

   If Gg < 251 Then
      Gx = Gg
   Else
      Gx = 251
      Select Case Gg
         Case 251
            Gx = Rnd(15)
         Case 252
            Gx = Rnd(30)
         Case 253
            Gx = Rnd(60)
         Case 254
            Gx = Rnd(120)
         Case 255
            Gx = Rnd(250)
      End Select
      G = Gx
   End If

   If Bb < 251 Then
      Bx = Bb
   Else
      Bx = 251
      Select Case Bb
         Case 251
            Bx = Rnd(15)
         Case 252
            Bx = Rnd(30)
         Case 253
            Bx = Rnd(60)
         Case 254
            Bx = Rnd(120)
         Case 255
            Bx = Rnd(250)
      End Select
      B = Bx
   End If

  Select Case Dans

  Case 0 : Call Snak_run_slow
  Case 1 : Call Snak_return_slow
  Case 2:
  Call Snak_run_slow
  Call Snak_return_slow
  Case 3 : Call Snak_run_fast
  Case 4 : Call Snak_return_fast
  Case 5:
  Call Snak_run_fast
  Call Snak_return_fast

  Case 6 : Call Snak_run_slow_random
  Case 7 : Call Snak_return_slow_random
  Case 8:
  Call Snak_run_slow_random
  Call Snak_return_slow_random
  Case 9 : Call Snak_run_fast_random
  Case 10 : Call Snak_return_fast_random
  Case 11:
  Call Snak_run_fast_random
  Call Snak_return_fast_random
  Case 12 : Call Snak_runreturn_slow_random
  Case 13 :
  Nnb = 0
  Call Half_snak_out_mid_slow
  Case 14 :
  Nnb = 1
  Call Half_snak_out_mid_slow
  Case 15 :
   Call Half_snak_out_mid_slow
   Toggle Nnb
      Goto Modh
  Case 16 : Call Half_half_right_slow
  Case 17 : Call Half_half_left_slow
  Case 18 :
  Mx = 0
   Call Star_run_slow
   Case 19 :
   Mx = 1
    Call Star_run_slow
  Case 20 : Call Star_runreturn_slow
  Case 21 : Call Star_run_fast
  Case 22 : Call Star_return_fast
  Case 23:
  Call Star_run_fast
  Call Star_return_fast
  Case 24 : Call Snak_growup_slow
  Case 25 : Call Star_playful
  Case 26 : Call Snak_star_playful
  Case 27 : Call Star_fillers
  Case 28 : Call Movable_light
  Case 29 : Call Snak_runreturn_colored
  Case 30 : Call Star_diamonds_blink_slow
  Case 31 : Call Star_diamonds_blink_fast
  Case 32 : Call Star_diamonds_blink_faster
  Case 33 : Call Disco
  Case 34 : Call Fillstripe_color
  Case 35 : Call Breathing
  Case 36 : Call Percolate_run
  Case 37 : Call Percolate_return
  Case 38 :
   Call Percolate_run
   Call Percolate_return
  Case 39 : Call Snak_1_2_run
  Case 40 : Call Snak_1_2_return
   Case 41 :
    Call Snak_1_2_run
    Call Snak_1_2_return
  Case 42 : Call Snak_1_2_run_rev
  Case 43 : Call Snak_1_2_return_rev
   Case 44 :
    Call Snak_1_2_run_rev
    Call Snak_1_2_return_rev
  Case 45 : Call Snak_relax_run
  Case 46 : Call Snak_relax_return
   Case 47 :
    Call Snak_relax_run
    Call Snak_relax_return
    Case 48 :
    Rainbo = 0
     Call Snak_rainbow
  Case 49 :
  Rainbo = 1
   Call Snak_rainbow
   Case 50 :
   Rainbo = 0
    Call Snak_rainbow
      Rainbo = 1
    Call Snak_rainbow

        Case 51 :
    Rainbo = 0
     Call Snak_rainbow_lp
  Case 52 :
  Rainbo = 1
   Call Snak_rainbow_lp
   Case 53 :
   Rainbo = 0
    Call Snak_rainbow_lp
      Rainbo = 1
    Call Snak_rainbow_lp
     Case 54 : Call Snak_rainbow_bl
     Case 55 :
       Rainbo = 0
      Call Snak_rise_fall_blink
      Case 56 :
       Rainbo = 1
      Call Snak_rise_fall_blink
      Case 57 : Comet_bounce
       Case 58 : Twinkle_fade
        Case 59 : Wave_pulse
        Case 60 : Call Wave_pulse_rev
        Case 61 : Call Wave_pulse_rr
          Case 62 : Call Meteor_rain
            Case 63 : Call Theater_chase
  Case 64 : Call Fire_flame
  Case 65 : Call Fire_flame_rev
  Case 66 : Call Fire_edges_in
  Case 67 : Call Fire_center_out
  Case 68 : Call Rain_drops
  Case 69 : Call Sparkle_two
  Case 70 : Call Stack_fill
  Case 71 : Call Stack_fill_rev
  Case 72 : Call Stack_edges_in
  Case 73 : Call Stack_center_out
  Case 74 : Call Heart_beat
  Case 75 : Call Lightning
  Case 76 : Call Plasma_wave
  Case 77 : Call Snake_cross
  Case 78 : Call Stripes_slide
  Case 79 : Call Meteor_shower
  Case 80 : Call Meteor_shower_rev
  Case 81 : Call Pendulum
  Case 82 : Call Gradient_scroll
  Case 83 : Call Pulse_rings
  Case 84 : Call Equalizer_bar
  Case 85 : Call Equalizer_bar_rev
  Case 86 : Call Equalizer_edges_in
  Case 87 : Call Equalizer_center_out
  Case 88 : Call Color_fade_walk
  Case 89 : Call Wave_collision
  Case 90 : Call Center_bloom
  Case 91 : Call Wander_block
  Case 92 : Call Sound_echo
  Case 93 : Call Sound_breathing
  Case 94 : Call Sound_center_out
  Case 95 : Call Sound_edges_in
  Case 96 : Call Sound_bar_peak
  Case 97 : Call Sound_sparkle
  End Select


End Sub



Sub Chekm
    If Tim1 > 999 Or Tim1 < 1 Then Tim1 = 1
    If Tim2 > 999 Or Tim2 < 1 Then Tim2 = 1
End Sub

Sub Time1
   Call Chekm
   For Tt1 = 0 To Tim1
      Reset Watchdog
      Waitms 1
      If Ina = 1 Then Exit For
   Next
     If Ina = 1 Then Goto Red
End Sub

Sub Time2
   Call Chekm
   For Tt2 = 0 To Tim2
      Reset Watchdog
      Waitms 1
      If Ina = 1 Then Exit For
   Next
   If Ina = 1 Then Goto Red
End Sub

Sub Memclr
                     R = 0
                     Print "   "
                      Print " Rangmang Wait "
                     For Ii = 0 To 800
                        Writeeeprom R , Ii
                        Reset Watchdog
                     Next
                      Print " Clear :) "
                     Rb_clearstripe
End Sub



''''''''''''''efects
   Sub Snak_run_slow

       R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led

          Rb_setcolor Nd , Color(1)
          Call Time1
          Rb_send
       Next
        R = 0 : G = 0 : B = 0
        For Nd = 0 To Led

           Rb_setcolor Nd , Color(1)
           Call Time2
           Rb_send
        Next
     End Sub

    Sub Snak_return_slow

       R = Rx : G = Gx : B = Bx
       For Nd = Led To 0 Step -1

          Rb_setcolor Nd , Color(1)
          Call Time1
          Rb_send
       Next
        R = 0 : G = 0 : B = 0
        For Nd = Led To 0 Step -1

           Rb_setcolor Nd , Color(1)
           Call Time2
           Rb_send
        Next
     End Sub

     Sub Snak_run_fast       '
       R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led Step 5
          Xfd = Nd + 1
          Yfd = Nd + 2
          Vfd = Nd + 3
          Bfd = Nd + 4
          Rb_setcolor Nd , Color(1)
          Rb_setcolor Xfd , Color(1)
          Rb_setcolor Yfd , Color(1)
          Rb_setcolor Vfd , Color(1)
          Rb_setcolor Bfd , Color(1)
          Call Time1
          Rb_send
       Next

        R = 0 : G = 0 : B = 0
        For Nd = 0 To Led Step 5
          Xfd = Nd + 1
          Yfd = Nd + 2
          Vfd = Nd + 3
          Bfd = Nd + 4
          Rb_setcolor Nd , Color(1)
          Rb_setcolor Xfd , Color(1)
          Rb_setcolor Yfd , Color(1)
          Rb_setcolor Vfd , Color(1)
          Rb_setcolor Bfd , Color(1)
           Call Time2
           Rb_send
        Next
     End Sub

     Sub Snak_return_fast
       R = Rx : G = Gx : B = Bx
       For Nd = Led To 0 Step -5
          Xfd = Nd + 1
          Yfd = Nd + 2
          Vfd = Nd + 3
          Bfd = Nd + 4
          Rb_setcolor Nd , Color(1)
          Rb_setcolor Xfd , Color(1)
          Rb_setcolor Yfd , Color(1)
          Rb_setcolor Vfd , Color(1)
          Rb_setcolor Bfd , Color(1)
          Call Time1
          Rb_send
       Next

        R = 0 : G = 0 : B = 0
        For Nd = Led To 0 Step -5
          Xfd = Nd + 1
          Yfd = Nd + 2
          Vfd = Nd + 3
          Bfd = Nd + 4
          Rb_setcolor Nd , Color(1)
          Rb_setcolor Xfd , Color(1)
          Rb_setcolor Yfd , Color(1)
          Rb_setcolor Vfd , Color(1)
          Rb_setcolor Bfd , Color(1)
           Call Time2
           Rb_send
        Next
      End Sub

     Sub Snak_run_slow_random
            For Nd = 0 To Led

             Jj = Nd Mod 2
             If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
             Rb_setcolor Nd , Color(1)
             Call Time1
             Rb_send
            Next
           R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1

             Rb_shiftright 0 , Led
             Call Time2
             Rb_send
           Next
           Rb_clearstripe
      End Sub
      Sub Snak_return_slow_random
            For Nd = Led To 0 Step -1
             Jj = Nd Mod 2
             If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
             Rb_setcolor Nd , Color(1)
             Call Time1
             Rb_send
            Next
           R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1
             Rb_shiftleft 0 , Led
             Call Time2
             Rb_send
           Next
           Rb_clearstripe
    End Sub

    Sub Snak_run_fast_random
            For Nd = 0 To Led Step 5
             Jj = Nd Mod 2
             If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
               Xfd = Nd + 1
               Yfd = Nd + 2
               Vfd = Nd + 3
               Bfd = Nd + 4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor Xfd , Color(1)
               Rb_setcolor Yfd , Color(1)
               Rb_setcolor Vfd , Color(1)
               Rb_setcolor Bfd , Color(1)
               Rb_send
               Call Time1
            Next
            R = 0 : G = 0 : B = 0
            For Nd = 0 To Led Step 5
               Xfd = Nd + 1
               Yfd = Nd + 2
               Vfd = Nd + 3
               Bfd = Nd + 4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor Xfd , Color(1)
               Rb_setcolor Yfd , Color(1)
               Rb_setcolor Vfd , Color(1)
               Rb_setcolor Bfd , Color(1)
               Rb_send
               Call Time2
            Next
            Rb_clearstripe
      End Sub
      Sub Snak_return_fast_random
            For Nd = Led To 4 Step -5
             Jj = Nd Mod 2
             If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
               Xfd = Nd - 1
               Yfd = Nd - 2
               Vfd = Nd - 3
               Bfd = Nd - 4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor Xfd , Color(1)
               Rb_setcolor Yfd , Color(1)
               Rb_setcolor Vfd , Color(1)
               Rb_setcolor Bfd , Color(1)
             Call Time1
             Rb_send
            Next
           R = 0 : G = 0 : B = 0
            For Nd = Led To 4 Step -5
               Xfd = Nd - 1
               Yfd = Nd - 2
               Vfd = Nd - 3
               Bfd = Nd - 4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor Xfd , Color(1)
               Rb_setcolor Yfd , Color(1)
               Rb_setcolor Vfd , Color(1)
               Rb_setcolor Bfd , Color(1)
             Call Time2
             Rb_send
            Next
            Rb_clearstripe
      End Sub

    Sub Snak_runreturn_slow_random
                   For Nd = Led To 0 Step -1

                   Jj = Nd Mod 2
                   If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
                   Rb_setcolor Nd , Color(1)
                   Call Time1
                   Rb_send
            Next
           R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1

             Rb_shiftright 0 , Led
             Call Time2
             Rb_send
           Next

            For Nd = 0 To Led

                   Jj = Nd Mod 2
                   If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
                   Rb_setcolor Nd , Color(1)
                   Call Time1
                   Rb_send
            Next
           R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1

             Rb_shiftleft 0 , Led
             Call Time2
             Rb_send
           Next
    End Sub


     Sub Half_snak_out_mid_slow
                R = Rx : G = Gx : B = Bx
           Jk = Led / 2
         If Nnb = 0 Then
         For Nd = 0 To Jk
               Kk = Led - Nd
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Kk , Color(1)
             Call Time1
             Rb_send
         Next

         Else

         For Nd = Jk To 0 Step -1
               Kk = Led - Nd
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Kk , Color(1)
             Call Time1
             Rb_send
         Next

         End If

       End Sub


      Sub Half_half_right_slow
          Rb_clearcolors
           R = Rx : G = Gx : B = Bx
           Jk = Led / 2
         For Nd = 0 To Jk
               Kk = Jk + Nd
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Kk , Color(1)
            Call Time1
             Rb_send
         Next

       End Sub

    Sub Half_half_left_slow
        Rb_clearcolors
           R = Rx : G = Gx : B = Bx
           Jk = Led / 2
         For Nd = Jk To 0 Step -1
               Kk = Jk + Nd
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Kk , Color(1)
            Call Time1
             Rb_send
         Next

       End Sub

   Sub Star_run_slow

         If Chc = 0 Then
           Ado = Led
           Chc = 1
         End If
         If Ado = 1 Then Chc = 0

         For Nd = 0 To Ado Step 2
              If Mx = 0 Then
                 R = Rx : G = Gx : B = Bx
               Else
                 R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
              End If
              Dvado = Nd + 1
             Rb_setcolor Nd , Color(1)
              Rb_setcolor Dvado , Color(1)
             Rb_send
             Call Time1
             Rb_clearcolors
         Next
      If Mx = 0 Then
          R = 222 : G = 222 : B = 222
         Else
          R = Rnd(222) : G = Rnd(222) : B = Rnd(222)
      End If




         If Ado > 10 Then

              Dvado = Ado / 10
            For Nd = Ado To Ado + Dvado
                Rb_setcolor Nd , Color(1)
            Next
           Else
           Rb_setcolor Ado , Color(1)
          End If
          Rb_send
          Call Time2
        If Chc = 1 Then
          If Ado > 10 Then
             Ado = Ado - Dvado
          Else
             Decr Ado
          End If
        End If

   End Sub


   Sub Star_runreturn_slow
         R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led Step 2
              Dvado = Nd + 1
             Rb_setcolor Nd , Color(1)
              Rb_setcolor Dvado , Color(1)
               Dvado = Nd + 2
              Rb_setcolor Dvado , Color(1)
          Rb_send
          Call Time1
          Rb_clearcolors
       Next         'call time1
       For Nd = Led To 0 Step -2
              Dvado = Nd + 1
              Rb_setcolor Nd , Color(1)
              Rb_setcolor Dvado , Color(1)
              Dvado = Nd + 2
              Rb_setcolor Dvado , Color(1)
         Rb_send
         Call Time2
         Rb_clearcolors
       Next
   End Sub
   Sub Star_run_fast
            R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led Step 5
               Xfd = Nd + 1
               Yfd = Nd + 2
               Vfd = Nd + 3
               Bfd = Nd + 4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor Xfd , Color(1)
               Rb_setcolor Yfd , Color(1)
               Rb_setcolor Vfd , Color(1)
               Rb_setcolor Bfd , Color(1)
          Rb_setcolor Nd , Color(1)
          Rb_send
          Call Time1
          Rb_clearcolors
       Next
     End Sub
     Sub Star_return_fast       'call time1
       For Nd = Led To 5 Step -5
               Xfd = Nd - 1
               Yfd = Nd - 2
               Vfd = Nd - 3
               Bfd = Nd - 4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor Xfd , Color(1)
               Rb_setcolor Yfd , Color(1)
               Rb_setcolor Vfd , Color(1)
               Rb_setcolor Bfd , Color(1)
         Rb_setcolor Nd , Color(1)
         Rb_send
         Call Time2
         Rb_clearcolors
       Next
   End Sub
Sub Snak_growup_slow
           R = Rx : G = Gx : B = Bx
           For Nd = 1 To 4
             Rb_setcolor Nd , Color(1)
             Next
             Rb_send

          If T < Led Then T = T + 5
          If T => Led Then T = 1

           For N = 1 To Led -t
             Rb_shiftright 0 , Led
             Call Time1
             Rb_send
           Next


           For Nd = Led -1 To Led -3 Step -1
             Rb_setcolor Nd , Color(1)
             Rb_send
             Reset Watchdog
             Next

           For N = 1 To Led -t

             Rb_shiftleft 0 , Led
             Call Time2
             Rb_send
           Next
End Sub

Sub Star_playful
           R = Rx : G = Gx : B = Bx
           For Nd = 1 To 4
             Rb_setcolor Nd , Color(1)
             Next
             Rb_send
           Yfd = Rnd(5)
          If T < Led Then T = T + Yfd
          If T => Led Then T = 1

           For N = 1 To Led -t
             Rb_shiftright 0 , Led
             Call Time1
             Rb_send
           Next

           Xfd = Rnd(5)
           For Nd = Led -1 To Led -xfd Step -5
             Rb_setcolor Nd , Color(1)
             Rb_send
             Reset Watchdog
             Next
              Vfd = Rnd(t)
           For N = 1 To Led -vfd

             Rb_shiftleft 0 , Led
             Call Time2
             Rb_send
           Next
End Sub

Sub Snak_star_playful
                If Led < 22 Then Led = 22
           Dim Pp As Byte
           Pp = Rnd(10) : If Pp = 0 Then Pp = 1
           R = Rx : G = Gx : B = Bx
           For Nd = 1 To Pp
             Rb_setcolor Nd , Color(1)
             Rb_send
             Next

           Pp = Rnd(10) : If Pp = 0 Then Pp = 1
          If T < Led Then T = T + 1
          If T => Led Then T = 1
              T = Rnd(t)
              T = T + Pp
              If T = 0 Then T = 1
           For N = 1 To Led -t Step Pp
              If N > 0 Then
             Rb_shiftright 0 , Led
             Rb_send
             End If
             Call Time1

           Next


           For Nd = Led -1 To Led -t Step -3
           If Nd > 0 Then
             Rb_setcolor Nd , Color(1)
             Rb_send
           End If
            Reset Watchdog
             Next

           Pp = Rnd(10) : If Pp = 0 Then Pp = 3
           For N = 1 To Led -t Step Pp
              If N > 0 Then
             Rb_shiftleft 0 , Led
             Rb_send
             End If
             Call Time2
           Next

       ''''''''''''''''''''''''''''''''''''''''
           Pp = Rnd(10) : If Pp = 0 Then Pp = 1



           Pp = Rnd(10) : If Pp = 0 Then Pp = 1
          If T < Led Then T = T + 1
          If T => Led Then T = 1
              T = Rnd(t)
              T = T + Pp
              If T = 0 Then T = 1
              Dim Jd , Md As Word
               Md = Rnd(led) : If Md < T Then Md = T + 1
           For N = 1 To Md -t Step Pp
           Jd = Led - Pp
              If N > 0 Then
             Rb_setcolor N , Color(1)
             Rb_send
             End If
             If Jd > 0 Then
             Rb_setcolor Jd , Color(1)
             Rb_send
             End If
             Call Time1

           Next


           For Nd = Led -t To Led -1 Step -3
           If Nd > 0 Then
             Rb_setcolor Nd , Color(1)
             Rb_send
           End If
             Reset Watchdog
             Next

           Pp = Rnd(10) : If Pp = 0 Then Pp = 3
           For N = Led -t To 1 Step Pp
              If N > 0 Then
             Rb_shiftright 0 , Led
             Rb_send
             End If
             Call Time2
           Next

            For Nd = 1 To Pp
             Rb_setcolor Nd , Color(1)
             Rb_send
             Next
End Sub
 Sub Star_fillers
             If Ado < Led Then Ado = Ado + 1
            If Ado = Led Then Ado = 1
           R = Rx : G = Gx : B = Bx
           For Nd = 1 To Ado Step 4
             Rb_setcolor Nd , Color(1)
             Rb_send
             Reset Watchdog
             Next



           For N = 1 To Led -ado Step -4

             Rb_shiftright 0 , Led
             Call Time1
             Rb_send
           Next


           For Nd = Led -1 To Led -ado Step -5
             Rb_setcolor Nd , Color(1)
             Rb_send
             Reset Watchdog
             Next

           For N = 1 To Led -ado

             Rb_shiftleft 0 , Led
             Call Time2
             Rb_send
           Next
 End Sub

 Sub Movable_light
           Xfd = Rnd(rx) : Yfd = Rnd(gx) : Vfd = Rnd(bx)
         For Nd = 0 To Led
             R = 222 : G = 222 : B = 222
             Jk = Nd + 1
             Kk = Nd + 2
             Lk = Nd + 3
             Rb_setcolor Lk , Color(1)
             Rb_setcolor Kk , Color(1)
             Rb_setcolor Jk , Color(1)
              R = Xfd : G = Yfd : B = Vfd
             Rb_setcolor Nd , Color(1)
             Call Time1
             Rb_send
         Next
           Xfd = Rnd(rx) : Yfd = Rnd(gx) : Vfd = Rnd(bx)
         For Nd = Led To 0 Step -1

             R = 222 : G = 222 : B = 222
             Jk = Nd + 1
             Kk = Nd + 2
             Lk = Nd + 3
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Jk , Color(1)
             Rb_setcolor Kk , Color(1)
              R = Xfd : G = Yfd : B = Vfd
             Rb_setcolor Lk , Color(1)
             Call Time2
             Rb_send
         Next
 End Sub

 Sub Snak_runreturn_colored
                R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         For Nd = 0 To Led

             Rb_setcolor Nd , Color(1)
             Call Time1
             Rb_send
         Next
          R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         For Nd = Led To 0 Step -1

             Rb_setcolor Nd , Color(1)
             Call Time2
             Rb_send
         Next
 End Sub
 Sub Star_diamonds_blink_slow
                         R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Call Time1
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Call Time2
                   Rb_send
 End Sub
  Sub Star_diamonds_blink_fast
               R = Rx : G = Gx : B = Bx
                   Call Time1
                   Call Time2
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Rb_send
                   Rb_clearcolors
 End Sub

 Sub Star_diamonds_blink_faster
                    R = Rx : G = Gx : B = Bx
                   Call Time1
                   Call Time2
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Rb_send
                   Rb_clearcolors

 End Sub

 Sub Disco
                   R = Rx : G = Gx : B = Bx
               For I = 0 To Led
                   Call Time1
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
               Next
                  Rb_send
                  R = 0 : G = 0 : B = 0
               For I = 0 To Led
                   Call Time2
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)

               Next
                  Rb_send
 End Sub

 Sub Fillstripe_color
                  R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
                    Rb_fillstripe Color
                    For I = 0 To 200
                      Call Time1
                      Call Time2
                      Next
 End Sub

 Sub Breathing
                A1 = Rx : A2 = Gx : A3 = Bx
                For Ll = 0 To 255
                  If A1 = 1 Or A2 = 1 Or A3 = 1 Then Exit For
                  If A1 > 1 Then Decr A1
                  If A2 > 1 Then Decr A2
                   If A3 > 1 Then Decr A3
                  R = A1 : G = A2 : B = A3
                    Rb_fillstripe Color
                      Call Time1
                Next

              For Ll = 0 To 255
               If A1 = Rx Or A2 = Gx Or A3 = Bx Then Exit For
               If A1 < Rx Then Incr A1
                If A2 < Gx Then Incr A2
                If A3 < Bx Then Incr A3
                R = A1 : G = A2 : B = A3
                    Rb_fillstripe Color
                      Call Time2
              Next
 End Sub

 Sub Percolate_run
           R = Rx : G = Gx : B = Bx
           Jk = Led / 2
         For Nd = 0 To Jk
               Kk = Led - Nd
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Kk , Color(1)
             Call Time1
             Rb_send
             Rb_clearcolors
             Reset Watchdog
         Next
 End Sub

 Sub Percolate_return
           R = Rx : G = Gx : B = Bx
           Jk = Led / 2
         For Nd = Jk To 0 Step -1
               Kk = Led - Nd
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Kk , Color(1)
             Waitms 1
             Rb_send
             Rb_clearcolors
             Reset Watchdog
         Next

 End Sub



 Sub Snak_1_2_run

      Rb_clearcolors
            R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led Step 2
          Rb_setcolor Nd , Color(1)
           Rb_send
          Call Time1
       Next
        R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
        If R < 10 Then R = 10
        If G < 10 Then G = 10
        If B < 10 Then B = 10
       For Nd = 1 To Led Step 2
          Rb_setcolor Nd , Color(1)
          Rb_send
          Call Time2
       Next
 End Sub

  Sub Snak_1_2_return
      Dvado = Led + 1
      Rb_clearcolors
            R = Rx : G = Gx : B = Bx
       For Nd = Led To 0 Step -2
          Rb_setcolor Nd , Color(1)
           Rb_send
          Call Time1
       Next
        R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
        If R < 10 Then R = 10
        If G < 10 Then G = 10
        If B < 10 Then B = 10
       For Nd = Dvado To 0 Step -2
          Rb_setcolor Nd , Color(1)
          Rb_send
          Call Time2
       Next
 End Sub

  Sub Snak_1_2_run_rev
      Dvado = Led + 1
      Rb_clearcolors
            R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led Step 2
          Rb_setcolor Nd , Color(1)
           Rb_send
          Call Time1
       Next
        R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
        If R < 10 Then R = 10
        If G < 10 Then G = 10
        If B < 10 Then B = 10
       For Nd = Led To 0 Step -2
          Rb_setcolor Nd , Color(1)
          Rb_send
          Call Time2
       Next
 End Sub

  Sub Snak_1_2_return_rev
      'Dvado = Led + 1
      Rb_clearcolors
            R = Rx : G = Gx : B = Bx
       For Nd = Led To 0 Step -2
          Rb_setcolor Nd , Color(1)
           Rb_send
          Call Time1
       Next
        R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
        If R < 10 Then R = 10
        If G < 10 Then G = 10
        If B < 10 Then B = 10
       For Nd = 0 To Led Step 2
          Rb_setcolor Nd , Color(1)
          Rb_send
          Call Time2
       Next
 End Sub

   Sub Snak_relax_run
     Rb_clearcolors
            R = Rx : G = Gx : B = Bx
          If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
            R = 0 : G = 0 : B = 0
       For Nd = Led To Led -10 Step -1
           R = Xfd + R : G = Yfd + G : B = Vfd + B
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
       For Nd = Led -11 To Led -20 Step -1
           R = R -xfd : G = G -yfd : B = B -vfd
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
      Rb_send

      For N = 0 To Led
            Rb_shiftleft 0 , Led
              Call Time1
             Rb_send
             Reset Watchdog
      Next

        Reset Watchdog
 End Sub

  Sub Snak_relax_return
     Rb_clearcolors
           R = Rx : G = Gx : B = Bx
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
            R = 0 : G = 0 : B = 0
       For Nd = 0 To 10
           R = Xfd + R : G = Yfd + G : B = Vfd + B
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
       For Nd = 11 To 21
           R = R -xfd : G = G -yfd : B = B -vfd
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
      Rb_send

      For N = 0 To Led
            Rb_shiftright 0 , Led
             Call Time1
             Rb_send
             Reset Watchdog
      Next

        Reset Watchdog
 End Sub

   Sub Snak_rainbow
       For I = 0 To 49
         R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
            R = 0 : G = 0 : B = 0

          Bfd = 20 * I
          Jk = 10 + Bfd
          Kk = 11 + Bfd
          Lk = 20 + Bfd
       For Nd = Bfd To Jk
           R = Xfd + R : G = Yfd + G : B = Vfd + B
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
       For Nd = Jk To Lk
           R = R -xfd : G = G -yfd : B = B -vfd
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next

     Next

        Rb_send

      For N = 0 To Led
         If Rainbo = 0 Then Rb_rotateright 0 , Led
         If Rainbo = 1 Then Rb_rotateleft 0 , Led
             Call Time1
             Rb_send
             Reset Watchdog
      Next

        Reset Watchdog
 End Sub

    Sub Snak_rainbow_lp
       For I = 0 To 49
         R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
            R = 0 : G = 0 : B = 0

          Bfd = 20 * I
          Jk = 10 + Bfd
          Kk = 11 + Bfd
          Lk = 20 + Bfd
       For Nd = Bfd To Jk
         R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
       For Nd = Jk To Lk
          R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next

     Next

        Rb_send

      For N = 0 To Led
         If Rainbo = 0 Then Rb_rotateright 0 , Led
         If Rainbo = 1 Then Rb_rotateleft 0 , Led
             Call Time1
             Rb_send
             Reset Watchdog
      Next

        Reset Watchdog
 End Sub

 Sub Snak_rainbow_bl
      Rb_clearcolors
   Rb_clearstripe
       For I = 0 To 49
        R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
            R = 0 : G = 0 : B = 0

          Bfd = 20 * I
          Lk = 20 + Bfd
       For Nd = Bfd To Lk
         R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
     Next
        Rb_send
           Call Time1
           Rb_rotateleft 0 , Led
             Rb_send
             Reset Watchdog
                    Rb_clearcolors
       Call Time2
        Reset Watchdog
 End Sub

 Sub Snak_rise_fall_blink

   For Nd = 0 To Jk

    If Rainbo = 1 Then Rb_clearstripe

      R = Rx
      G = Gx
      B = Bx

         Rb_setcolor Nd , Color(1)
          Waitms 1
         Rb_send
         Ii = Led - nd
         Rb_setcolor Ii , Color(1)
          Waitms 1
         Rb_send

          Call Time1

   Next

    Jk = Led / 2

   For Nd = 0 To Jk

    If Rainbo = 1 Then Rb_clearstripe

      R = 0
      G = 0
      B = 0

         Rb_setcolor Nd , Color(1)
          Waitms 1
         Rb_send
         Ii = Led - nd
         Rb_setcolor Ii , Color(1)
          Waitms 1
         Rb_send

          Call Time1

   Next

      For Nd = 0 To Jk

    If Rainbo = 1 Then Rb_clearstripe

      R = Rx
      G = Gx
      B = Bx

      For Kk = Jk - Nd To Jk + Nd
         Rb_setcolor Kk , Color(1)
      Next

      Rb_send

       Call Time1

   Next
   Call Time2
 End Sub

 Sub Comet_bounce

   For Nd = 0 To Led + 12
      Rb_clearcolors
      For Kk = 0 To 12
         If Nd >= Kk Then
            Jk = Nd - Kk
            If Jk <= Led Then
               Vfd = 12 - Kk
               Xfd = Rx : Xfd = Xfd * Vfd : Xfd = Xfd / 12
               Yfd = Gx : Yfd = Yfd * Vfd : Yfd = Yfd / 12
               Bfd = Bx : Bfd = Bfd * Vfd : Bfd = Bfd / 12
               R = Xfd : G = Yfd : B = Bfd
               Rb_setcolor Jk , Color(1)
            End If
         End If
      Next
      Rb_send
      Call Time1
   Next


   For Nd = 0 To Led + 12
      Rb_clearcolors
      For Kk = 0 To 12
         Lk = Led + Kk
         If Lk >= Nd And Nd >= Kk Then
            Jk = Lk - Nd
            Vfd = 12 - Kk
            Xfd = Rx : Xfd = Xfd * Vfd : Xfd = Xfd / 12
            Yfd = Gx : Yfd = Yfd * Vfd : Yfd = Yfd / 12
            Bfd = Bx : Bfd = Bfd * Vfd : Bfd = Bfd / 12
            R = Xfd : G = Yfd : B = Bfd
            Rb_setcolor Jk , Color(1)
         End If
      Next
      Rb_send
      Call Time2
   Next
End Sub

Sub Twinkle_fade
   Dim Tw As Byte
   Dim Tn As Word
   Dim Tlev As Word
   Dim Tpos(40) As Word

   Tn = Led / 8
   If Tn < 3 Then Tn = 3
   If Tn > 40 Then Tn = 40

   For Tw = 1 To Tn
      Tpos(tw) = Rnd(Led)
      Reset Watchdog
   Next

   For Tlev = 8 To 0 Step -1
      Xfd = Rx : Xfd = Xfd * Tlev : Xfd = Xfd / 8
      Yfd = Gx : Yfd = Yfd * Tlev : Yfd = Yfd / 8
      Vfd = Bx : Vfd = Vfd * Tlev : Vfd = Vfd / 8
      R = Xfd : G = Yfd : B = Vfd
      Rb_clearcolors
      For Tw = 1 To Tn
         Rb_setcolor Tpos(tw) , Color(1)
      Next
      Rb_send
      Call Time1
   Next

   Call Time2
End Sub

Sub Wave_pulse


   Wlen = 32                       ' wave length in pixels (even number)

   For Wp = 0 To Wlen - 1          ' shift wave by one pixel each pass
      For Nd = 0 To Led
         Wk = Nd + Wp
         Wk = Wk Mod Wlen          ' position inside wave: 0 to 31

         If Wk < 16 Then           ' rising half
            Wv = Wk
         Else                      ' falling half
            Wv = Wlen - 1
            Wv = Wv - Wk
         End If                    ' Wv is 0 to 15

         Xfd = Rx : Xfd = Xfd * Wv : Xfd = Xfd / 15
         Yfd = Gx : Yfd = Yfd * Wv : Yfd = Yfd / 15
         Vfd = Bx : Vfd = Vfd * Wv : Vfd = Vfd / 15

         R = Xfd : G = Yfd : B = Vfd
         Rb_setcolor Nd , Color(1)
      Next
      Rb_send
      Call Time1
   Next

   Call Time2
End Sub

Sub Wave_pulse_rev


   Wlen = 32                       ' wave length in pixels (even number)

   For Wp = 0 To Wlen - 1
      For Nd = 0 To Led
         Wk = Nd + Wlen
         Wk = Wk - Wp              ' minus Wp = opposite direction
         Wk = Wk Mod Wlen

         If Wk < 16 Then
            Wv = Wk
         Else
            Wv = Wlen - 1
            Wv = Wv - Wk
         End If

         Xfd = Rx : Xfd = Xfd * Wv : Xfd = Xfd / 15
         Yfd = Gx : Yfd = Yfd * Wv : Yfd = Yfd / 15
         Vfd = Bx : Vfd = Vfd * Wv : Vfd = Vfd / 15

         R = Xfd : G = Yfd : B = Vfd
         Rb_setcolor Nd , Color(1)
      Next
      Rb_send
      Call Time1
   Next

   Call Time2
End Sub

Sub Wave_pulse_rr


   Wlen = 32                       ' wave length in pixels (even number)

   ' ---- forward pass ----
   For Wp = 0 To Wlen - 1
      For Nd = 0 To Led
         Wk = Nd + Wp
         Wk = Wk Mod Wlen

         If Wk < 16 Then
            Wv = Wk
         Else
            Wv = Wlen - 1
            Wv = Wv - Wk
         End If

         Xfd = Rx : Xfd = Xfd * Wv : Xfd = Xfd / 15
         Yfd = Gx : Yfd = Yfd * Wv : Yfd = Yfd / 15
         Vfd = Bx : Vfd = Vfd * Wv : Vfd = Vfd / 15

         R = Xfd : G = Yfd : B = Vfd
         Rb_setcolor Nd , Color(1)
      Next
      Rb_send
      Call Time1
   Next

   ' ---- backward pass ----
   For Wp = 0 To Wlen - 1
      For Nd = 0 To Led
         Wk = Nd + Wlen
         Wk = Wk - Wp
         Wk = Wk Mod Wlen

         If Wk < 16 Then
            Wv = Wk
         Else
            Wv = Wlen - 1
            Wv = Wv - Wk
         End If

         Xfd = Rx : Xfd = Xfd * Wv : Xfd = Xfd / 15
         Yfd = Gx : Yfd = Yfd * Wv : Yfd = Yfd / 15
         Vfd = Bx : Vfd = Vfd * Wv : Vfd = Vfd / 15

         R = Xfd : G = Yfd : B = Vfd
         Rb_setcolor Nd , Color(1)
      Next
      Rb_send
      Call Time2
   Next
End Sub

Sub Meteor_rain
   Mh = Led / 2

   ' ---- two meteors move toward the middle ----
   For Mq = 0 To Mh
      Rb_clearcolors
      R = Rx : G = Gx : B = Bx
      Rb_setcolor Mq , Color(1)
      Mw = Led - Mq
      Rb_setcolor Mw , Color(1)

      ' dim trail behind each meteor
      If Mq > 0 Then
         Xfd = Rx / 4 : Yfd = Gx / 4 : Vfd = Bx / 4
         R = Xfd : G = Yfd : B = Vfd
         Jk = Mq - 1
         Rb_setcolor Jk , Color(1)
         Kk = Mw + 1
         Rb_setcolor Kk , Color(1)
      End If

      Rb_send
      Call Time1
   Next

   ' ---- explosion in the middle: grows outward ----
   R = Rx : G = Gx : B = Bx
   For Mq = 0 To Mh
      Jk = Mh - Mq
      Kk = Mh + Mq
      Rb_setcolor Jk , Color(1)
      Rb_setcolor Kk , Color(1)
      Rb_send
      Call Time1
   Next

   Call Time2
   Rb_clearcolors
   Rb_send
End Sub

Sub Theater_chase
   ' ---- forward chase ----
   For Tq = 1 To 10
      For Tc = 0 To 2
         Rb_clearcolors
         R = Rx : G = Gx : B = Bx
         For Nd = Tc To Led Step 3
            Rb_setcolor Nd , Color(1)
            Reset Watchdog
         Next
         Rb_send
         Call Time1
      Next
   Next

   ' ---- backward chase ----
   For Tq = 1 To 10
      For Tc = 2 To 0 Step -1
         Rb_clearcolors
         R = Rx : G = Gx : B = Bx
         For Nd = Tc To Led Step 3
            Rb_setcolor Nd , Color(1)
            Reset Watchdog
         Next
         Rb_send
         Call Time2
      Next
   Next

   ' ---- clear at end ----
   Rb_clearcolors
   Rb_send
End Sub

Sub Fire_flame
   Fmode = 0
   Call Fire_core
End Sub

Sub Fire_flame_rev
   Fmode = 1
   Call Fire_core
End Sub

Sub Fire_edges_in
   Fmode = 2
   Call Fire_core
End Sub

Sub Fire_center_out
   Fmode = 3
   Call Fire_core
End Sub

Sub Fire_core
   ' Fmode: 0 = base at start, 1 = base at end
   '        2 = both edges to middle, 3 = middle to both edges
   Flim = Led
   If Fmode > 1 Then Flim = Led / 2
   If Flim < 2 Then Flim = 2
   Fmid = Led / 2

   For Fc = 1 To 100

      ' random flame height, at least one third of the available length
      Fh = Rnd(Flim)
      Fm = Flim / 3
      If Fh < Fm Then Fh = Fm
      If Fh > 600 Then Fh = 600
      If Fh > Flim Then Fh = Flim

      ' middle of the flame
      Fm = Fh / 2

      Rb_clearcolors

      For Fp = 0 To Fh

         ' brightness: 255 at the base down to 0 at the top
         Fv = Fh - Fp
         Fv = Fv * 100
         If Fh > 0 Then Fv = Fv / Fh
         Fv = Fv * 255
         Fv = Fv / 100

         ' random flicker per pixel
         Fq = Rnd(60)
         If Fv > Fq Then Fv = Fv - Fq

         ' scale the input color by brightness Fv (0 to 255)
         Xfd = Rx
         Xfd = Xfd * Fv
         Xfd = Xfd / 255
         Yfd = Gx
         Yfd = Yfd * Fv
         Yfd = Yfd / 255
         Vfd = Bx
         Vfd = Vfd * Fv
         Vfd = Vfd / 255

         ' upper half of the flame is dimmer
         If Fp > Fm Then
            Xfd = Xfd / 2
            Yfd = Yfd / 2
            Vfd = Vfd / 2
         End If

         R = Xfd
         G = Yfd
         B = Vfd

         ' pixel positions for each mode
         Select Case Fmode
            Case 0
               Fa = Fp
            Case 1
               Fa = Led - Fp
            Case 2
               Fa = Fp
               Fb = Led - Fp
            Case 3
               Fa = Fmid + Fp
               Fb = Fmid - Fp
         End Select

         Rb_setcolor Fa , Color(1)
         If Fmode > 1 Then Rb_setcolor Fb , Color(1)
         Reset Watchdog
      Next

      Rb_send
      Call Time1
   Next

   Call Time2

   ' clear at end
   Rb_clearcolors
   Rb_send
End Sub

Sub Rain_drops
   ' maximum wave radius is one eighth of the strip, 4 to 60
   Dmax = Led / 8
   If Dmax < 4 Then Dmax = 4
   If Dmax > 60 Then Dmax = 60

   For Dn = 1 To 8

      ' random drop position
      Dpos = Rnd(Led)

      ' wave expands from the drop point
      For Dw = 0 To Dmax
         Rb_clearcolors

         ' brightness falls as the wave grows
         Dv = Dmax - Dw
         Dv = Dv * 100
         Dv = Dv / Dmax

         Xfd = Rx
         Xfd = Xfd * Dv
         Xfd = Xfd / 100
         Yfd = Gx
         Yfd = Yfd * Dv
         Yfd = Yfd / 100
         Vfd = Bx
         Vfd = Vfd * Dv
         Vfd = Vfd / 100

         R = Xfd
         G = Yfd
         B = Vfd

         ' right side of the ring, only inside the strip
         Da = Dpos + Dw
         If Da <= Led Then Rb_setcolor Da , Color(1)

         ' left side of the ring, only if not below zero
         If Dpos >= Dw Then
            Db = Dpos - Dw
            Rb_setcolor Db , Color(1)
         End If

         Rb_send
         Call Time1
      Next

      Call Time2
   Next

   ' clear at end
   Rb_clearcolors
   Rb_send
End Sub

Sub Sparkle_two
   ' complement color: 255 minus each channel
   Kr = 255 - Rx
   Kg = 255 - Gx
   Kb = 255 - Bx

   ' number of sparkles per frame
   Kq = Led / 10
   If Kq < 3 Then Kq = 3
   If Kq > 40 Then Kq = 40

   For Kc = 1 To 60

      ' dim background of the main color (one eighth)
      Xfd = Rx / 8
      Yfd = Gx / 8
      Vfd = Bx / 8
      R = Xfd
      G = Yfd
      B = Vfd
      Rb_fillstripe Color

      ' sparkles with the main color
      R = Rx
      G = Gx
      B = Bx
      For Kn = 1 To Kq
         Nd = Rnd(Led)
         Rb_setcolor Nd , Color(1)
         Reset Watchdog
      Next

      ' sparkles with the complement color
      R = Kr
      G = Kg
      B = Kb
      For Kn = 1 To Kq
         Nd = Rnd(Led)
         Rb_setcolor Nd , Color(1)
         Reset Watchdog
      Next

      Rb_send
      Call Time1
   Next

   Call Time2

   ' clear at end
   Rb_clearcolors
   Rb_send
End Sub

Sub Stack_fill
   Zmode = 0
   Call Stack_core
End Sub

Sub Stack_fill_rev
   Zmode = 1
   Call Stack_core
End Sub

Sub Stack_edges_in
   Zmode = 2
   Call Stack_core
End Sub

Sub Stack_center_out
   Zmode = 3
   Call Stack_core
End Sub

Sub Stack_put
   ' Zx = virtual position, converted to real pixel(s) by mode
   ' Zmode: 0 = start to end, 1 = end to start
   '        2 = edges to middle, 3 = middle to edges
   Select Case Zmode
      Case 0 :
         Za = Zx
      Case 1 :
         Za = Led - Zx
      Case 2 :
         Za = Zx
         Zc = Led - Zx
      Case 3 :
         Za = Zmid + Zx
         Zc = Zmid - Zx
   End Select

   Rb_setcolor Za , Color(1)
   If Zmode > 1 Then Rb_setcolor Zc , Color(1)
End Sub

Sub Stack_core
   ' virtual strip length: full strip, or half for the middle modes
   Zv = Led
   If Zmode > 1 Then Zv = Led / 2
   If Zv < 2 Then Zv = 2
   Zmid = Led / 2

   ' block size so there are at most 40 bricks
   Zb = Zv / 40
   If Zb < 1 Then Zb = 1
   Zn = Zv / Zb

   ' last pixel of the last brick, and brick width minus one
   Ze = Zn * Zb
   Ze = Ze - 1
   Zk = Zb - 1

   ' last stack step
   Zlast = Zn - 1

   R = Rx : G = Gx : B = Bx

   ' Zs = bricks already stacked
   For Zs = 0 To Zlast

      ' last position of the moving brick
      Zl = Zn - Zs
      Zl = Zl - 1

      For Zp = 0 To Zl
         Rb_clearcolors

         ' draw stacked bricks
         If Zs > 0 Then
            Zt = Zn - Zs
            Zt = Zt * Zb
            For Zx = Zt To Ze
               Call Stack_put
            Next
         End If

         ' draw the moving brick
         Zt = Zp * Zb
         For Zy = 0 To Zk
            Zx = Zt + Zy
            Call Stack_put
         Next

         Rb_send
         Call Time1
      Next
      Reset Watchdog
   Next

   Call Time2

   ' clear at end
   Rb_clearcolors
   Rb_send
End Sub

Sub Heart_pulse
   ' Hmax = peak level 0 to 100 (percent of the input color)
   ' rise quickly, then fall in steps
   For Hl = 0 To Hmax Step 20
      Xfd = Rx
      Xfd = Xfd * Hl
      Xfd = Xfd / 100
      Yfd = Gx
      Yfd = Yfd * Hl
      Yfd = Yfd / 100
      Vfd = Bx
      Vfd = Vfd * Hl
      Vfd = Vfd / 100
      R = Xfd
      G = Yfd
      B = Vfd
      Rb_fillstripe Color
      Waitms 5
      Reset Watchdog
   Next

   For Hl = Hmax To 0 Step -5
      Xfd = Rx
      Xfd = Xfd * Hl
      Xfd = Xfd / 100
      Yfd = Gx
      Yfd = Yfd * Hl
      Yfd = Yfd / 100
      Vfd = Bx
      Vfd = Vfd * Hl
      Vfd = Vfd / 100
      R = Xfd
      G = Yfd
      B = Vfd
      Rb_fillstripe Color
      Call Time1
   Next
End Sub

Sub Heart_beat
   For Hc = 1 To 6

      ' first beat (strong)
      Hmax = 100
      Call Heart_pulse

      ' short gap between the two beats
      For Hp = 0 To 60
         Waitms 1
         Reset Watchdog
      Next

      ' second beat (weaker)
      Hmax = 60
      Call Heart_pulse

      ' long rest, controlled by E
      Call Time2
      Call Time2
   Next

   ' clear at end
   Rb_clearcolors
   Rb_send
End Sub

Sub Lightning
   ' maximum branch length: one third of the strip
   Lmax = Led / 3
   If Lmax < 4 Then Lmax = 4

   For Lc = 1 To 5

      ' random strike position
      Lp = Rnd(Led)

      ' ---- branch spreads from the strike point ----
      R = Rx : G = Gx : B = Bx
      Rb_clearcolors
      For Lw = 0 To Lmax

         ' right side, only inside the strip
         La = Lp + Lw
         If La <= Led Then Rb_setcolor La , Color(1)

         ' left side, only if not below zero
         If Lp >= Lw Then
            Lb = Lp - Lw
            Rb_setcolor Lb , Color(1)
         End If

         Rb_send
         Call Time1
      Next

      ' ---- quick flicker of the whole strip ----
      For Lf = 1 To 3
         R = Rx : G = Gx : B = Bx
         Rb_fillstripe Color
         Waitms 30
         Rb_clearstripe
         Waitms 40
         Reset Watchdog
      Next

      ' ---- fade out ----
      Rb_clearcolors
      Rb_send

      ' long pause before next strike, controlled by E
      Call Time2
      Call Time2
   Next

   ' clear at end
   Rb_clearcolors
   Rb_send
End Sub

Sub Plasma_wave
   For Pc = 0 To 400

      For Nd = 0 To Led

         ' wave A: period 40 pixels, moves forward
         Pa = Nd + Pc
         Pa = Pa Mod 40
         If Pa > 19 Then
            Pa = 39 - Pa
         End If

         ' wave B: period 62 pixels, moves backward
         Pb = Nd + 62
         Pb = Pb * 1
         Pq = Pc * 2
         Pq = Pq Mod 62
         If Pb < Pq Then Pb = Pb + 62
         Pb = Pb - Pq
         Pb = Pb Mod 62
         If Pb > 30 Then
            Pb = 61 - Pb
         End If

         ' Pa is 0 to 19, Pb is 0 to 30, sum is 0 to 49
         Pv = Pa + Pb

         Xfd = Rx
         Xfd = Xfd * Pv
         Xfd = Xfd / 49
         Yfd = Gx
         Yfd = Yfd * Pv
         Yfd = Yfd / 49
         Vfd = Bx
         Vfd = Vfd * Pv
         Vfd = Vfd / 49

         R = Xfd
         G = Yfd
         B = Vfd
         Rb_setcolor Nd , Color(1)
      Next

      Rb_send
      Call Time1
      Reset Watchdog
   Next

   Call Time2

   ' clear at end
   Rb_clearcolors
   Rb_send
End Sub

Sub Snake_cross
   ' snake body length: one twentieth of the strip, 6 to 40
   Qlen = Led / 20
   If Qlen < 6 Then Qlen = 6
   If Qlen > 40 Then Qlen = 40

   ' head length: about one quarter of the body, at least 2
   Qh = Qlen / 4
   If Qh < 2 Then Qh = 2

   ' both snakes use the input color for the body
   Qr = Rx
   Qg = Gx
   Qbl = Bx

   ' head color: input channels rotated (R to G to B to R)
   Qhr = Bx
   Qhg = Rx
   Qhb = Gx

   For Qc = 1 To 4

      For Qp = 0 To Led

         Rb_clearcolors

         For Qk = 0 To Qlen

            ' brightness: full at the head, zero at the tail
            Qv = Qlen - Qk
            Qv = Qv * 100
            Qv = Qv / Qlen

            ' ---- snake A: moves start to end ----
            If Qp >= Qk Then
               Qa = Qp - Qk

               If Qk < Qh Then
                  Xfd = Qhr
                  Yfd = Qhg
                  Vfd = Qhb
               Else
                  Xfd = Rx
                  Yfd = Gx
                  Vfd = Bx
               End If

               Xfd = Xfd * Qv
               Xfd = Xfd / 100
               Yfd = Yfd * Qv
               Yfd = Yfd / 100
               Vfd = Vfd * Qv
               Vfd = Vfd / 100
               R = Xfd
               G = Yfd
               B = Vfd
               Rb_setcolor Qa , Color(1)
            End If

            ' ---- snake B: moves end to start ----
            Qb = Led - Qp
            Qb = Qb + Qk
            If Qb <= Led Then

               If Qk < Qh Then
                  Xfd = Qhr
                  Yfd = Qhg
                  Vfd = Qhb
               Else
                  Xfd = Qr
                  Yfd = Qg
                  Vfd = Qbl
               End If

               Xfd = Xfd * Qv
               Xfd = Xfd / 100
               Yfd = Yfd * Qv
               Yfd = Yfd / 100
               Vfd = Vfd * Qv
               Vfd = Vfd / 100
               R = Xfd
               G = Yfd
               B = Vfd
               Rb_setcolor Qb , Color(1)
            End If

         Next

         Rb_send
         Call Time1
      Next

      Call Time2
   Next

   ' clear at end
   Rb_clearcolors
   Rb_send
End Sub

Sub Stripes_slide
   ' stripe width: one tenth of the strip, 4 to 60
   Tsw = Led / 10
   If Tsw < 4 Then Tsw = 4
   If Tsw > 60 Then Tsw = 60

   ' pattern period is two stripes
   Tsh = Tsw * 2

   ' second color: input channels rotated
   Tsr = Bx
   Tsg = Rx
   Tsb = Gx

   For Tsc = 1 To 2

      ' ---- slide forward, speed S ----
      For Tsp = 0 To Tsh
         For Nd = 0 To Led
            Tsk = Nd + Tsp
            Tsk = Tsk Mod Tsh
            If Tsk < Tsw Then
               R = Rx : G = Gx : B = Bx
            Else
               R = Tsr : G = Tsg : B = Tsb
            End If
            Rb_setcolor Nd , Color(1)
         Next
         Rb_send
         Call Time1
         Reset Watchdog
      Next

      ' ---- slide backward, speed E ----
      For Tsp = 0 To Tsh
         For Nd = 0 To Led
            Tsk = Nd + Tsh
            Tsk = Tsk - Tsp
            Tsk = Tsk Mod Tsh
            If Tsk < Tsw Then
               R = Rx : G = Gx : B = Bx
            Else
               R = Tsr : G = Tsg : B = Tsb
            End If
            Rb_setcolor Nd , Color(1)
         Next
         Rb_send
         Call Time2
         Reset Watchdog
      Next

   Next

   ' clear at end
   Rb_clearcolors
   Rb_send
End Sub

Sub Meteor_shower
   Mtd = 0
   Call Meteor_core
End Sub

Sub Meteor_shower_rev
   Mtd = 1
   Call Meteor_core
End Sub

Sub Meteor_core
   ' Mtd: 0 = start to end, 1 = end to start
   ' spawn 4 meteors at random positions with random tail lengths
   For Mti = 1 To 4
      Mtp(mti) = Rnd(Led)
      Mtl(mti) = Rnd(10)
      Mtl(mti) = Mtl(mti) + 6
   Next

   ' run for a fixed number of frames
   For Mtf = 1 To 400

      Rb_clearcolors

      For Mti = 1 To 4

         For Mtk = 0 To Mtl(mti)

            ' virtual position of this tail part, only if not below zero
            Mta = Mtp(mti)
            If Mta >= Mtk Then
               Mta = Mta - Mtk
               If Mta <= Led Then

                  ' brightness: full at the head, zero at the tail end
                  Mtv = Mtl(mti)
                  Mtv = Mtv - Mtk
                  Mtv = Mtv * 100
                  Mtc = Mtl(mti)
                  Mtv = Mtv / Mtc

                  Xfd = Rx
                  Xfd = Xfd * Mtv
                  Xfd = Xfd / 100
                  Yfd = Gx
                  Yfd = Yfd * Mtv
                  Yfd = Yfd / 100
                  Vfd = Bx
                  Vfd = Vfd * Mtv
                  Vfd = Vfd / 100

                  ' the head is whiter: add 80 to each channel
                  If Mtk = 0 Then
                     Xfd = Xfd + 80
                     Yfd = Yfd + 80
                     Vfd = Vfd + 80
                     If Xfd > 255 Then Xfd = 255
                     If Yfd > 255 Then Yfd = 255
                     If Vfd > 255 Then Vfd = 255
                  End If

                  R = Xfd
                  G = Yfd
                  B = Vfd

                  ' convert virtual position to real pixel
                  If Mtd = 1 Then Mta = Led - Mta
                  Rb_setcolor Mta , Color(1)
               End If
            End If
         Next

         ' move this meteor one step forward
         Mtc = Mtp(mti)
         Incr Mtc
         Mtp(mti) = Mtc

         ' when the whole meteor left the strip, respawn it
         Mtc = Led + Mtl(mti)
         If Mtp(mti) > Mtc Then
            Mtp(mti) = 0
            Mtl(mti) = Rnd(10)
            Mtl(mti) = Mtl(mti) + 6
         End If
         Reset Watchdog
      Next

      Rb_send
      Call Time1
   Next

   Call Time2

   ' clear at end
   Rb_clearcolors
   Rb_send
End Sub

Sub Pendulum
   ' second color: input channels rotated
   Pdr = Bx
   Pdg = Rx
   Pdbl = Gx

   For Pdc = 1 To 6

      ' Pdt = time step 0 to 64, one full swing
      For Pdt = 0 To 64

         ' triangle time 0 to 32 to 0
         If Pdt <= 32 Then
            Pdx = Pdt
         Else
            Pdx = 64 - Pdt
         End If

         ' ease in and out: x * (64 - x) is 0 to 1024 at x = 32
         Pdv = 64 - Pdx
         Pdv = Pdv * Pdx

         ' position A = Led * Pdv / 1024, split to avoid overflow
         Pda = Led / 8
         Pda = Pda * Pdv
         Pda = Pda / 128
         If Pda > Led Then Pda = Led

         ' position B is the mirror
         Pdb = Led - Pda

         Rb_clearcolors

         ' tail of 3 pixels behind each dot
         For Pdk = 0 To 3
            Pdw = 4 - Pdk
            Pdw = Pdw * 25

            ' dot A
            Xfd = Rx
            Xfd = Xfd * Pdw
            Xfd = Xfd / 100
            Yfd = Gx
            Yfd = Yfd * Pdw
            Yfd = Yfd / 100
            Vfd = Bx
            Vfd = Vfd * Pdw
            Vfd = Vfd / 100
            R = Xfd
            G = Yfd
            B = Vfd
            If Pda >= Pdk Then
               Pdx = Pda - Pdk
               Rb_setcolor Pdx , Color(1)
            End If

            ' dot B
            Xfd = Pdr
            Xfd = Xfd * Pdw
            Xfd = Xfd / 100
            Yfd = Pdg
            Yfd = Yfd * Pdw
            Yfd = Yfd / 100
            Vfd = Pdbl
            Vfd = Vfd * Pdw
            Vfd = Vfd / 100
            R = Xfd
            G = Yfd
            B = Vfd
            Pdx = Pdb + Pdk
            If Pdx <= Led Then Rb_setcolor Pdx , Color(1)
         Next

         Rb_send
         Call Time1
      Next

      Call Time2
   Next

   ' clear at end
   Rb_clearcolors
   Rb_send
End Sub

Sub Gradient_scroll
   ' gradient period in pixels: Led / 2, at least 20, at most 200
   Gsh = Led / 2
   If Gsh < 20 Then Gsh = 20
   If Gsh > 200 Then Gsh = 200

   ' half period (rise then fall)
   Gsw = Gsh / 2

   ' second color: input channels rotated
   Gsr = Bx
   Gsg = Rx
   Gsb = Gx

   For Gsc = 1 To 3

      ' ---- scroll forward, speed S ----
      For Gsp = 0 To Gsh
         For Nd = 0 To Led

            ' position inside the period
            Gsk = Nd + Gsp
            Gsk = Gsk Mod Gsh

            ' triangle: 0 to Gsw then back to 0
            If Gsk <= Gsw Then
               Gsv = Gsk
            Else
               Gsv = Gsh - Gsk
            End If

            ' mix weight 0 to 100 (percent of second color)
            Gsv = Gsv * 100
            Gsv = Gsv / Gsw

            ' mix = first * (100 - w) + second * w, divided by 100
            Xfd = Rx
            Xfd = Xfd * 100
            Yfd = Rx
            Yfd = Yfd * Gsv
            Xfd = Xfd - Yfd
            Yfd = Gsr
            Yfd = Yfd * Gsv
            Xfd = Xfd + Yfd
            Xfd = Xfd / 100
            R = Xfd

            Xfd = Gx
            Xfd = Xfd * 100
            Yfd = Gx
            Yfd = Yfd * Gsv
            Xfd = Xfd - Yfd
            Yfd = Gsg
            Yfd = Yfd * Gsv
            Xfd = Xfd + Yfd
            Xfd = Xfd / 100
            G = Xfd

            Xfd = Bx
            Xfd = Xfd * 100
            Yfd = Bx
            Yfd = Yfd * Gsv
            Xfd = Xfd - Yfd
            Yfd = Gsb
            Yfd = Yfd * Gsv
            Xfd = Xfd + Yfd
            Xfd = Xfd / 100
            B = Xfd

            Rb_setcolor Nd , Color(1)
         Next
         Rb_send
         Call Time1
         Reset Watchdog
      Next

      ' ---- scroll backward, speed E ----
      For Gsp = 0 To Gsh
         For Nd = 0 To Led

            Gsk = Nd + Gsh
            Gsk = Gsk - Gsp
            Gsk = Gsk Mod Gsh

            If Gsk <= Gsw Then
               Gsv = Gsk
            Else
               Gsv = Gsh - Gsk
            End If

            Gsv = Gsv * 100
            Gsv = Gsv / Gsw

            Xfd = Rx
            Xfd = Xfd * 100
            Yfd = Rx
            Yfd = Yfd * Gsv
            Xfd = Xfd - Yfd
            Yfd = Gsr
            Yfd = Yfd * Gsv
            Xfd = Xfd + Yfd
            Xfd = Xfd / 100
            R = Xfd

            Xfd = Gx
            Xfd = Xfd * 100
            Yfd = Gx
            Yfd = Yfd * Gsv
            Xfd = Xfd - Yfd
            Yfd = Gsg
            Yfd = Yfd * Gsv
            Xfd = Xfd + Yfd
            Xfd = Xfd / 100
            G = Xfd

            Xfd = Bx
            Xfd = Xfd * 100
            Yfd = Bx
            Yfd = Yfd * Gsv
            Xfd = Xfd - Yfd
            Yfd = Gsb
            Yfd = Yfd * Gsv
            Xfd = Xfd + Yfd
            Xfd = Xfd / 100
            B = Xfd

            Rb_setcolor Nd , Color(1)
         Next
         Rb_send
         Call Time2
         Reset Watchdog
      Next

   Next

   ' clear at end
   Rb_clearcolors
   Rb_send
End Sub

Sub Pulse_rings
   ' middle of the strip
   Prm = Led / 2

   ' ring band width: one twentieth of the strip, 4 to 30
   Prw = Led / 20
   If Prw < 4 Then Prw = 4
   If Prw > 30 Then Prw = 30

   ' ring period is 2 bands (ring + gap)
   Prh = Prw * 2

   ' second color: input channels rotated
   Prr = Bx
   Prg = Rx
   Prbl = Gx

   For Prc = 1 To 3

      ' rings move outward, speed S
      For Prp = 0 To Prh
         Call Pulse_rings_draw
         Call Time1
      Next

      ' rings move inward, speed E
      For Prp = 0 To Prh
         Call Pulse_rings_draw_in
         Call Time2
      Next

   Next

   ' clear at end
   Rb_clearcolors
   Rb_send
End Sub

Sub Pulse_rings_draw
   For Nd = 0 To Led

      ' distance from the middle
      If Nd >= Prm Then
         Prd = Nd - Prm
      Else
         Prd = Prm - Nd
      End If

      ' ring index and position inside the period (moves outward)
      Prk = Prd + Prh
      Prk = Prk - Prp
      Prv = Prk Mod Prh

      ' which ring: even uses input color, odd uses rotated
      Prk = Prk / Prh
      Prz = Prk Mod 2

      If Prv < Prw Then
         If Prz = 0 Then
            R = Rx : G = Gx : B = Bx
         Else
            R = Prr : G = Prg : B = Prbl
         End If
      Else
         R = 0 : G = 0 : B = 0
      End If

      Rb_setcolor Nd , Color(1)
   Next
   Rb_send
   Reset Watchdog
End Sub

Sub Pulse_rings_draw_in
   For Nd = 0 To Led

      If Nd >= Prm Then
         Prd = Nd - Prm
      Else
         Prd = Prm - Nd
      End If

      ' same as outward, but the phase runs the other way
      Prk = Prd + Prp
      Prv = Prk Mod Prh

      Prk = Prk / Prh
      Prz = Prk Mod 2

      If Prv < Prw Then
         If Prz = 0 Then
            R = Rx : G = Gx : B = Bx
         Else
            R = Prr : G = Prg : B = Prbl
         End If
      Else
         R = 0 : G = 0 : B = 0
      End If

      Rb_setcolor Nd , Color(1)
   Next
   Rb_send
   Reset Watchdog
End Sub

Sub Equalizer_bar
   Evm = 0
   Call Eq_core
End Sub

Sub Equalizer_bar_rev
   Evm = 1
   Call Eq_core
End Sub

Sub Equalizer_edges_in
   Evm = 2
   Call Eq_core
End Sub

Sub Equalizer_center_out
   Evm = 3
   Call Eq_core
End Sub

Sub Eq_put
   ' Evx = virtual position, converted to real pixel(s) by mode
   ' Evm: 0 = start up, 1 = end down, 2 = edges to middle, 3 = middle to edges
   Select Case Evm
      Case 0 :
         Evy = Evx
      Case 1 :
         Evy = Led - Evx
      Case 2 :
         Evy = Evx
         Evz = Led - Evx
      Case 3 :
         Evy = Evd + Evx
         Evz = Evd - Evx
   End Select

   Rb_setcolor Evy , Color(1)
   If Evm > 1 Then Rb_setcolor Evz , Color(1)
End Sub

Sub Eq_core
   ' virtual length: full strip, or half for the two middle modes
   Evv = Led
   If Evm > 1 Then Evv = Led / 2
   If Evv < 4 Then Evv = 4
   Evd = Led / 2

   ' step per frame: one twentieth of the length, at least 1
   Evs = Evv / 20
   If Evs < 1 Then Evs = 1

   ' peak dot width: one fiftieth of the length, at least 2
   Evw = Evv / 50
   If Evw < 2 Then Evw = 2

   ' peak color: input channels rotated
   Evr = Bx
   Evg = Rx
   Evb = Gx

   Evl = 0
   Evk = 0
   Evh = 0
   Evt = Rnd(Evv)

   For Evc = 1 To 300

      ' move the bar level toward the target
      If Evl < Evt Then
         Eva = Evt - Evl
         If Eva > Evs Then Eva = Evs
         Evl = Evl + Eva
      ElseIf Evl > Evt Then
         Eva = Evl - Evt
         If Eva > Evs Then Eva = Evs
         Evl = Evl - Eva
      Else
         Evt = Rnd(Evv)
      End If

      ' peak dot: follows the bar up, holds, then falls one pixel per frame
      If Evl > Evk Then
         Evk = Evl
         Evh = 0
      Else
         If Evh < 250 Then Incr Evh
         If Evh > 8 Then
            If Evk > Evl Then Decr Evk
         End If
      End If

      Rb_clearcolors

      ' draw the bar
      R = Rx : G = Gx : B = Bx
      For Evx = 0 To Evl
         Call Eq_put
      Next

      ' draw the peak dot
      R = Evr : G = Evg : B = Evb
      Eva = Evk + Evw
      If Eva > Evv Then Eva = Evv
      For Evx = Evk To Eva
         Call Eq_put
      Next

      Rb_send
      Call Time1
      Reset Watchdog
   Next

   Call Time2

   ' clear at end
   Rb_clearcolors
   Rb_send
End Sub

Sub Color_fade_walk
   ' three key colors: input, rotated once, rotated twice
   Cfa(1) = Rx
   Cfb(1) = Gx
   Cfg(1) = Bx
   Cfa(2) = Bx
   Cfb(2) = Rx
   Cfg(2) = Gx
   Cfa(3) = Gx
   Cfb(3) = Bx
   Cfg(3) = Rx

   For Cfc = 1 To 3

      ' go from key color Cfi to the next key color
      For Cfi = 1 To 3
         Cfj = Cfi + 1
         If Cfj > 3 Then Cfj = 1

         ' weight 0 to 100 percent of the next color
         For Cfw = 0 To 100

            ' red channel: first * (100 - w) + second * w, divided by 100
            Xfd = Cfa(cfi)
            Xfd = Xfd * 100
            Yfd = Cfa(cfi)
            Yfd = Yfd * Cfw
            Xfd = Xfd - Yfd
            Yfd = Cfa(cfj)
            Yfd = Yfd * Cfw
            Xfd = Xfd + Yfd
            Xfd = Xfd / 100
            R = Xfd

            ' green channel
            Xfd = Cfb(cfi)
            Xfd = Xfd * 100
            Yfd = Cfb(cfi)
            Yfd = Yfd * Cfw
            Xfd = Xfd - Yfd
            Yfd = Cfb(cfj)
            Yfd = Yfd * Cfw
            Xfd = Xfd + Yfd
            Xfd = Xfd / 100
            G = Xfd

            ' blue channel
            Xfd = Cfg(cfi)
            Xfd = Xfd * 100
            Yfd = Cfg(cfi)
            Yfd = Yfd * Cfw
            Xfd = Xfd - Yfd
            Yfd = Cfg(cfj)
            Yfd = Yfd * Cfw
            Xfd = Xfd + Yfd
            Xfd = Xfd / 100
            B = Xfd

            Rb_fillstripe Color
            Call Time1
            Reset Watchdog
         Next
      Next
   Next

   Call Time2

   ' clear at end
   Rb_clearcolors
   Rb_send
End Sub

Sub Wave_collision
   ' half of the strip
   Wch = Led / 2

   ' half width of each block: one twentieth of the strip, 4 to 40
   Wcw = Led / 20
   If Wcw < 4 Then Wcw = 4
   If Wcw > 40 Then Wcw = 40

   ' second color: input channels rotated
   Wcr = Bx
   Wcg = Rx
   Wcb2 = Gx

   For Wcc = 1 To 3

      ' ---- blocks move toward the middle ----
      For Wcp = 0 To Wch
         Rb_clearcolors

         For Wck = 0 To Wcw

            ' brightness: full at the center of the block, zero at the edge
            Wcv = Wcw - Wck
            Wcv = Wcv * 100
            Wcv = Wcv / Wcw

            ' ---- block A, input color, center at Wcp ----
            Xfd = Rx
            Xfd = Xfd * Wcv
            Xfd = Xfd / 100
            Yfd = Gx
            Yfd = Yfd * Wcv
            Yfd = Yfd / 100
            Vfd = Bx
            Vfd = Vfd * Wcv
            Vfd = Vfd / 100
            R = Xfd
            G = Yfd
            B = Vfd

            Wca = Wcp + Wck
            If Wca <= Led Then Rb_setcolor Wca , Color(1)
            If Wcp >= Wck Then
               Wca = Wcp - Wck
               Rb_setcolor Wca , Color(1)
            End If

            ' ---- block B, rotated color, center at Led - Wcp ----
            Xfd = Wcr
            Xfd = Xfd * Wcv
            Xfd = Xfd / 100
            Yfd = Wcg
            Yfd = Yfd * Wcv
            Yfd = Yfd / 100
            Vfd = Wcb2
            Vfd = Vfd * Wcv
            Vfd = Vfd / 100
            R = Xfd
            G = Yfd
            B = Vfd

            Wcb = Led - Wcp
            Wca = Wcb + Wck
            If Wca <= Led Then Rb_setcolor Wca , Color(1)
            If Wcb >= Wck Then
               Wca = Wcb - Wck
               Rb_setcolor Wca , Color(1)
            End If
         Next

         Rb_send
         Call Time1
         Reset Watchdog
      Next

      ' ---- white flash in the middle ----
      R = 255 : G = 255 : B = 255
      Rb_fillstripe Color
      Waitms 60
      Rb_clearstripe
      Waitms 40

      ' ---- blocks continue to the opposite ends ----
      For Wcp = 0 To Wch
         Rb_clearcolors

         For Wck = 0 To Wcw
            Wcv = Wcw - Wck
            Wcv = Wcv * 100
            Wcv = Wcv / Wcw

            ' block A continues from the middle to the end
            Xfd = Rx
            Xfd = Xfd * Wcv
            Xfd = Xfd / 100
            Yfd = Gx
            Yfd = Yfd * Wcv
            Yfd = Yfd / 100
            Vfd = Bx
            Vfd = Vfd * Wcv
            Vfd = Vfd / 100
            R = Xfd
            G = Yfd
            B = Vfd

            Wcb = Wch + Wcp
            Wca = Wcb + Wck
            If Wca <= Led Then Rb_setcolor Wca , Color(1)
            If Wcb >= Wck Then
               Wca = Wcb - Wck
               If Wca <= Led Then Rb_setcolor Wca , Color(1)
            End If

            ' block B continues from the middle to the start
            Xfd = Wcr
            Xfd = Xfd * Wcv
            Xfd = Xfd / 100
            Yfd = Wcg
            Yfd = Yfd * Wcv
            Yfd = Yfd / 100
            Vfd = Wcb2
            Vfd = Vfd * Wcv
            Vfd = Vfd / 100
            R = Xfd
            G = Yfd
            B = Vfd

            If Wch >= Wcp Then
               Wcb = Wch - Wcp
               Wca = Wcb + Wck
               If Wca <= Led Then Rb_setcolor Wca , Color(1)
               If Wcb >= Wck Then
                  Wca = Wcb - Wck
                  Rb_setcolor Wca , Color(1)
               End If
            End If
         Next

         Rb_send
         Call Time1
         Reset Watchdog
      Next

      Call Time2
   Next

   ' clear at end
   Rb_clearcolors
   Rb_send
End Sub

Sub Center_bloom
   ' middle of the strip
   Bmmid = Led / 2

   ' growth step per frame: one fortieth of the half, at least 1
   Bmstep = Bmmid / 40
   If Bmstep < 1 Then Bmstep = 1

   ' second color: input channels rotated
   Bmrot1 = Bx
   Bmrot2 = Rx
   Bmrot3 = Gx

   For Bmcnt = 1 To 2

      ' ---- bloom grows from the middle, speed S ----
      For Bmrad = 0 To Bmmid Step Bmstep

         For Nd = 0 To Led

            ' distance from the middle
            If Nd >= Bmmid Then
               Bmdist = Nd - Bmmid
            Else
               Bmdist = Bmmid - Nd
            End If

            If Bmdist > Bmrad Then
               R = 0 : G = 0 : B = 0
            Else
               ' weight 0 to 100: 0 at the middle, 100 at the bloom edge
               Bmwgt = Bmdist * 100
               If Bmrad > 0 Then Bmwgt = Bmwgt / Bmrad

               ' brightness 100 at the middle down to 30 at the edge
               Bmbri = Bmwgt * 7
               Bmbri = Bmbri / 10
               Bmbri = 100 - Bmbri

               ' red: mix colors, then scale by brightness
               Xfd = Rx
               Xfd = Xfd * 100
               Yfd = Rx
               Yfd = Yfd * Bmwgt
               Xfd = Xfd - Yfd
               Yfd = Bmrot1
               Yfd = Yfd * Bmwgt
               Xfd = Xfd + Yfd
               Xfd = Xfd / 100
               Xfd = Xfd * Bmbri
               Xfd = Xfd / 100
               R = Xfd

               ' green
               Xfd = Gx
               Xfd = Xfd * 100
               Yfd = Gx
               Yfd = Yfd * Bmwgt
               Xfd = Xfd - Yfd
               Yfd = Bmrot2
               Yfd = Yfd * Bmwgt
               Xfd = Xfd + Yfd
               Xfd = Xfd / 100
               Xfd = Xfd * Bmbri
               Xfd = Xfd / 100
               G = Xfd

               ' blue
               Xfd = Bx
               Xfd = Xfd * 100
               Yfd = Bx
               Yfd = Yfd * Bmwgt
               Xfd = Xfd - Yfd
               Yfd = Bmrot3
               Yfd = Yfd * Bmwgt
               Xfd = Xfd + Yfd
               Xfd = Xfd / 100
               Xfd = Xfd * Bmbri
               Xfd = Xfd / 100
               B = Xfd
            End If

            Rb_setcolor Nd , Color(1)
         Next

         Rb_send
         Call Time1
         Reset Watchdog
      Next

      ' ---- fade the whole strip out, speed E ----
      For Bmfade = 100 To 0 Step -5
         For Nd = 0 To Led

            If Nd >= Bmmid Then
               Bmdist = Nd - Bmmid
            Else
               Bmdist = Bmmid - Nd
            End If

            Bmwgt = Bmdist * 100
            If Bmmid > 0 Then Bmwgt = Bmwgt / Bmmid
            If Bmwgt > 100 Then Bmwgt = 100

            Bmbri = Bmwgt * 7
            Bmbri = Bmbri / 10
            Bmbri = 100 - Bmbri
            Bmbri = Bmbri * Bmfade
            Bmbri = Bmbri / 100

            ' red
            Xfd = Rx
            Xfd = Xfd * 100
            Yfd = Rx
            Yfd = Yfd * Bmwgt
            Xfd = Xfd - Yfd
            Yfd = Bmrot1
            Yfd = Yfd * Bmwgt
            Xfd = Xfd + Yfd
            Xfd = Xfd / 100
            Xfd = Xfd * Bmbri
            Xfd = Xfd / 100
            R = Xfd

            ' green
            Xfd = Gx
            Xfd = Xfd * 100
            Yfd = Gx
            Yfd = Yfd * Bmwgt
            Xfd = Xfd - Yfd
            Yfd = Bmrot2
            Yfd = Yfd * Bmwgt
            Xfd = Xfd + Yfd
            Xfd = Xfd / 100
            Xfd = Xfd * Bmbri
            Xfd = Xfd / 100
            G = Xfd

            ' blue
            Xfd = Bx
            Xfd = Xfd * 100
            Yfd = Bx
            Yfd = Yfd * Bmwgt
            Xfd = Xfd - Yfd
            Yfd = Bmrot3
            Yfd = Yfd * Bmwgt
            Xfd = Xfd + Yfd
            Xfd = Xfd / 100
            Xfd = Xfd * Bmbri
            Xfd = Xfd / 100
            B = Xfd

            Rb_setcolor Nd , Color(1)
         Next
         Rb_send
         Call Time2
         Reset Watchdog
      Next

   Next

   ' clear at end
   Rb_clearcolors
   Rb_send
End Sub

Sub Wander_block
   ' block width is Led / 3, so half width is Led / 6
   Wglhlf = Led / 6
   If Wglhlf < 3 Then Wglhlf = 3

   ' fast movement: pixels per frame, at least 1
   Wglstp = Led / 100
   If Wglstp < 1 Then Wglstp = 1

   ' start in the middle, random mode, random count
   ' Wgldir: 0 = right, 1 = left, 2 = stop and breathe
   Wglctr = Led / 2
   Wgldir = Rnd(3)
   Wglcnt = Rnd(80)
   Wglcnt = Wglcnt + 20
   Wglphs = 0

   For Wglfrm = 1 To 800

      ' ---- count frames, then pick a new random mode ----
      If Wglcnt > 0 Then
         Decr Wglcnt
      Else
         Wgldir = Rnd(3)
         Wglcnt = Rnd(80)
         Wglcnt = Wglcnt + 20
      End If

      ' ---- move the block, bounce at both ends ----
      If Wgldir = 0 Then
         Wglctr = Wglctr + Wglstp
         If Wglctr >= Led Then
            Wglctr = Led
            Wgldir = 1
         End If
      ElseIf Wgldir = 1 Then
         If Wglctr > Wglstp Then
            Wglctr = Wglctr - Wglstp
         Else
            Wglctr = 0
            Wgldir = 0
         End If
      End If

      ' ---- breathing brightness: triangle wave 0 to 100 ----
      ' while moving the block is at full brightness
      Wglbrt = 100
      If Wgldir = 2 Then
         Incr Wglphs
         If Wglphs > 59 Then Wglphs = 0
         If Wglphs < 30 Then
            Wglbrt = Wglphs
         Else
            Wglbrt = 59 - Wglphs
         End If
         ' 0 to 29 scaled to 20 to 100 percent
         Wglbrt = Wglbrt * 80
         Wglbrt = Wglbrt / 29
         Wglbrt = Wglbrt + 20
      End If

      ' ---- first and last pixel of the block ----
      If Wglctr >= Wglhlf Then
         Wglbeg = Wglctr - Wglhlf
      Else
         Wglbeg = 0
      End If
      Wglend = Wglctr + Wglhlf
      If Wglend > Led Then Wglend = Led

      ' ---- draw: full color in the middle, dim at the sides ----
      Rb_clearcolors
      For Wglidx = Wglbeg To Wglend

         ' distance from the block center
         If Wglidx >= Wglctr Then
            Wgldst = Wglidx - Wglctr
         Else
            Wgldst = Wglctr - Wglidx
         End If

         ' shape: 100 at the center, 0 at the edge
         Wglwgt = Wglhlf - Wgldst
         Wglwgt = Wglwgt * 100
         Wglwgt = Wglwgt / Wglhlf

         ' apply breathing brightness
         Wglwgt = Wglwgt * Wglbrt
         Wglwgt = Wglwgt / 100

         Xfd = Rx
         Xfd = Xfd * Wglwgt
         Xfd = Xfd / 100
         Yfd = Gx
         Yfd = Yfd * Wglwgt
         Yfd = Yfd / 100
         Vfd = Bx
         Vfd = Vfd * Wglwgt
         Vfd = Vfd / 100
         R = Xfd
         G = Yfd
         B = Vfd
         Rb_setcolor Wglidx , Color(1)
      Next

      Rb_send
      Call Time1
      Reset Watchdog
   Next

   Call Time2

   ' clear at end
   Rb_clearcolors
   Rb_send
End Sub


''''''''''''''''''''''''''''''''''sound effect



Sub Sound_echo
   Noise = 30
        Adcmin = 1023
   Adcmax = 0
   For Adcidx = 1 To 8
      Adcval = Getadc(0)
      If Adcval < Adcmin Then Adcmin = Adcval
      If Adcval > Adcmax Then Adcmax = Adcval
   Next
   Adcamp = Adcmax - Adcmin
   If Adcamp > 0 And Adcamp < Noise Then Adcamp = 0
       Print Adcamp

   If Adcamp > Noise Then
       Adcidx = Adcamp / Led
         Head = Adcidx / Led
      ' ---- draw the bar ----
      Rb_clearcolors
      R = Rx : G = Gx : B = Bx
      For Nd = 0 To Adcidx
         Rb_setcolor Nd , Color(1)
      Next
      Rb_send
      R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
      For Nd = Nd To Nd + head
         Rb_setcolor Nd , Color(1)
      Next
      Rb_send

      ' Time1 (S) is the frame delay for both rise and fall
      'Call Time1
      Reset Watchdog
   Else
    Rb_clearcolors
    Rb_clearstripe

   End If
End Sub

Sub Sound_breathing
   Noise = 40
   Adcmin = 1023
   Adcmax = 0
   For Adcidx = 1 To 4
      Adcval = Getadc(0)
      If Adcval < Adcmin Then Adcmin = Adcval
      If Adcval > Adcmax Then Adcmax = Adcval
   Next
   Adcamp = Adcmax - Adcmin

   If Adcamp <= Noise Then
      Target = 0
   Else
      Target = Adcamp - Noise
      Target = Target * 3
      If Target > 255 Then Target = 255
   End If

   Oldlevel = Level

   If Target > Level Then
      Level = Level + 40
      If Level > Target Then Level = Target
   Elseif Target < Level Then
      If Level > 12 Then
         Level = Level - 12
      Else
         Level = 0
      End If
   End If

   If Level <> Oldlevel Then
      Tmp = Rx : Tmp = Tmp * Level : Tmp = Tmp / 255 : R = Tmp
      Tmp = Gx : Tmp = Tmp * Level : Tmp = Tmp / 255 : G = Tmp
      Tmp = Bx : Tmp = Tmp * Level : Tmp = Tmp / 255 : B = Tmp
      Rb_fillstripe Color
   End If
   Reset Watchdog
End Sub


Sub Sound_center_out
   Noise = 40
   Adcmin = 1023
   Adcmax = 0
   For Adcidx = 1 To 4
      Adcval = Getadc(0)
      If Adcval < Adcmin Then Adcmin = Adcval
      If Adcval > Adcmax Then Adcmax = Adcval
   Next
   Adcamp = Adcmax - Adcmin

   If Adcamp > Noise Then
      Dv = 1000 - Tim2
      If Dv < 1 Then Dv = 1
      Tmp = Adcamp - Noise
      Tmp = Tmp * 100
      Tmp = Tmp / Dv
      If Tmp > 1000 Then Tmp = 1000
      Level = Tmp
   Else
      Level = 0
   End If

   Zmid = Led / 2

   If Level <> Oldlevel Then
      If Level > Oldlevel Then
         R = Rx : G = Gx : B = Bx
         Zp = Oldlevel
         While Zp < Level
            Zk = Zmid + Zp
            Rb_setcolor Zk , Color(1)
            If Zmid >= Zp Then
               Zk = Zmid - Zp
               Rb_setcolor Zk , Color(1)
            End If
            Incr Zp
         Wend
      Else
         R = 0 : G = 0 : B = 0
         Zp = Oldlevel
         While Zp > Level
            Decr Zp
            Zk = Zmid + Zp
            Rb_setcolor Zk , Color(1)
            If Zmid >= Zp Then
               Zk = Zmid - Zp
               Rb_setcolor Zk , Color(1)
            End If
         Wend
      End If
      Oldlevel = Level
      Rb_send
   End If
   Reset Watchdog
End Sub

Sub Sound_edges_in
   Noise = 40
   Adcmin = 1023
   Adcmax = 0
   For Adcidx = 1 To 4
      Adcval = Getadc(0)
      If Adcval < Adcmin Then Adcmin = Adcval
      If Adcval > Adcmax Then Adcmax = Adcval
   Next
   Adcamp = Adcmax - Adcmin

   If Adcamp > Noise Then
      Dv = 1000 - Tim2
      If Dv < 1 Then Dv = 1
      Tmp = Adcamp - Noise
      Tmp = Tmp * 100
      Tmp = Tmp / Dv
      If Tmp > 1000 Then Tmp = 1000
      Level = Tmp
   Else
      Level = 0
   End If

   If Level <> Oldlevel Then
      If Level > Oldlevel Then
         R = Rx : G = Gx : B = Bx
         Zp = Oldlevel
         While Zp < Level
            Zk = Led - Zp
            Rb_setcolor Zk , Color(1)
            Rb_setcolor Zp , Color(1)
            Incr Zp
         Wend
      Else
         R = 0 : G = 0 : B = 0
         Zp = Oldlevel
         While Zp > Level
            Decr Zp
            Zk = Led - Zp
            Rb_setcolor Zk , Color(1)
            Rb_setcolor Zp , Color(1)
         Wend
      End If
      Oldlevel = Level
      Rb_send
   End If
   Reset Watchdog
End Sub

Sub Sound_bar_peak
   Noise = 40
   Adcmin = 1023
   Adcmax = 0
   For Adcidx = 1 To 4
      Adcval = Getadc(0)
      If Adcval < Adcmin Then Adcmin = Adcval
      If Adcval > Adcmax Then Adcmax = Adcval
   Next
   Adcamp = Adcmax - Adcmin

   If Adcamp > Noise Then
      Dv = 1000 - Tim2
      If Dv < 1 Then Dv = 1
      Tmp = Adcamp - Noise
      Tmp = Tmp * 100
      Tmp = Tmp / Dv
      If Tmp > 1000 Then Tmp = 1000
      Level = Tmp
   Else
      Level = 0
   End If
   If Level > Led Then Level = Led

   ' bar
   If Level > Oldlevel Then
      R = Rx : G = Gx : B = Bx
      Zp = Oldlevel
      While Zp < Level
         Rb_setcolor Zp , Color(1)
         Incr Zp
      Wend
   Elseif Level < Oldlevel Then
      R = 0 : G = 0 : B = 0
      Zp = Oldlevel
      While Zp > Level
         Decr Zp
         Rb_setcolor Zp , Color(1)
      Wend
   End If
   Oldlevel = Level

   ' peak: follows the bar up, falls slowly
   If Level >= Zl Then
      Zl = Level
   Else
      Incr Zk
      If Zk > 5 Then
         Zk = 0
         If Zl > 0 Then
            R = 0 : G = 0 : B = 0
            Rb_setcolor Zl , Color(1)
            Decr Zl
         End If
      End If
   End If

   R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
   Rb_setcolor Zl , Color(1)
   Rb_send
   Reset Watchdog
End Sub

Sub Sound_sparkle
   Noise = 40
   Adcmin = 1023
   Adcmax = 0
   For Adcidx = 1 To 4
      Adcval = Getadc(0)
      If Adcval < Adcmin Then Adcmin = Adcval
      If Adcval > Adcmax Then Adcmax = Adcval
   Next
   Adcamp = Adcmax - Adcmin

   If Adcamp > Noise Then
      Dv = 1000 - Tim2
      If Dv < 1 Then Dv = 1
      Tmp = Adcamp - Noise
      Tmp = Tmp * 100
      Tmp = Tmp / Dv
      If Tmp > 1000 Then Tmp = 1000
      Level = Tmp
   Else
      Level = 0
   End If
   If Level > 60 Then Level = 60

   Rb_clearcolors
   If Level > 0 Then
      For Zp = 1 To Level
         R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         Nd = Rnd(Led)
         Rb_setcolor Nd , Color(1)
      Next
   End If
   Rb_send
   Reset Watchdog
End Sub